//! Seven Design I/O.
//!
//! - [`codec`]: decode PNG/JPEG to a [`sevendesign_render::Raster`]; encode PNG / PNG with
//!   transparency / JPEG.
//! - [`store`]: [`AssetStore`], the renderer's picture source: decodes from disk on demand and
//!   keeps a size-bounded LRU cache of mip levels, so a zoomed-out view never holds full photos.
//! - [`project`]: [`Project`], a project folder (`document.json`, `assets/`, `fonts/`), saved
//!   atomically with a `.bak` of the previous save.

pub mod codec;
pub mod project;
pub mod store;

pub use codec::{ExportFormat, decode_image, encode};
pub use project::{Project, flatten_color};
pub use store::AssetStore;

#[derive(Debug, thiserror::Error)]
pub enum IoError {
    #[error("file error: {0}")]
    Io(String),
    #[error("image could not be read: {0}")]
    Decode(String),
    #[error("image could not be written: {0}")]
    Encode(String),
    #[error("image of {0}x{1} pixels is too large")]
    TooLarge(u32, u32),
    #[error("not a usable font file")]
    BadFont,
    #[error(transparent)]
    Doc(#[from] sevendesign_doc::DocError),
    #[error(transparent)]
    Render(#[from] sevendesign_render::RenderError),
}

impl From<std::io::Error> for IoError {
    fn from(e: std::io::Error) -> Self {
        IoError::Io(e.to_string())
    }
}
