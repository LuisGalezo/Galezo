use std::io::Cursor;

use sevendesign_doc::Rgba;
use sevendesign_render::Raster;

use crate::IoError;

/// Largest picture accepted on import, in pixels (RGBA8: 4 bytes each while decoded).
pub const MAX_DECODE_PIXELS: u64 = 80_000_000;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ExportFormat {
    /// PNG with the alpha channel (transparent background stays transparent).
    PngTransparent,
    /// PNG without alpha: flattened over `flatten_over`.
    Png { flatten_over: Rgba },
    /// JPEG (1..=100), flattened over `flatten_over`.
    Jpeg { quality: u8, flatten_over: Rgba },
}

fn reader(bytes: &[u8]) -> Result<image::ImageReader<Cursor<&[u8]>>, IoError> {
    image::ImageReader::new(Cursor::new(bytes)).with_guessed_format().map_err(|e| IoError::Decode(e.to_string()))
}

/// Pixel size of a PNG/JPEG without decoding it.
pub fn dimensions(bytes: &[u8]) -> Result<(u32, u32), IoError> {
    reader(bytes)?.into_dimensions().map_err(|e| IoError::Decode(e.to_string()))
}

/// Decodes a PNG or JPEG to straight RGBA8. The size is checked first, so an enormous file is
/// refused before any pixel memory is allocated. (JPEG EXIF orientation is applied by the
/// caller; the Android side rotates camera photos before importing.)
pub fn decode_image(bytes: &[u8]) -> Result<Raster, IoError> {
    let (w, h) = dimensions(bytes)?;
    if u64::from(w) * u64::from(h) > MAX_DECODE_PIXELS || w == 0 || h == 0 {
        return Err(IoError::TooLarge(w, h));
    }
    let img = reader(bytes)?.decode().map_err(|e| IoError::Decode(e.to_string()))?.to_rgba8();
    let (w, h) = (img.width(), img.height());
    Raster::from_rgba(w, h, img.into_raw()).ok_or(IoError::TooLarge(w, h))
}

/// Straight RGBA over an opaque colour -> RGB8.
pub fn flatten(r: &Raster, over: Rgba) -> Vec<u8> {
    let mut rgb = Vec::with_capacity(r.w as usize * r.h as usize * 3);
    for p in r.px.chunks_exact(4) {
        let a = u32::from(p[3]);
        for c in 0..3 {
            let v = (u32::from(p[c]) * a + u32::from(over.0[c]) * (255 - a) + 127) / 255;
            rgb.push(v as u8);
        }
    }
    rgb
}

/// Encodes rendered pixels in the chosen format.
pub fn encode(r: &Raster, format: ExportFormat) -> Result<Vec<u8>, IoError> {
    let enc = |e: image::ImageError| IoError::Encode(e.to_string());
    let mut out = Cursor::new(Vec::new());
    match format {
        ExportFormat::PngTransparent => {
            image::ImageEncoder::write_image(image::codecs::png::PngEncoder::new(&mut out), &r.px, r.w, r.h, image::ExtendedColorType::Rgba8).map_err(enc)?;
        }
        ExportFormat::Png { flatten_over } => {
            let rgb = flatten(r, flatten_over);
            image::ImageEncoder::write_image(image::codecs::png::PngEncoder::new(&mut out), &rgb, r.w, r.h, image::ExtendedColorType::Rgb8).map_err(enc)?;
        }
        ExportFormat::Jpeg { quality, flatten_over } => {
            let rgb = flatten(r, flatten_over);
            image::ImageEncoder::write_image(
                image::codecs::jpeg::JpegEncoder::new_with_quality(&mut out, quality.clamp(1, 100)),
                &rgb,
                r.w,
                r.h,
                image::ExtendedColorType::Rgb8,
            )
            .map_err(enc)?;
        }
    }
    Ok(out.into_inner())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample() -> Raster {
        // 2x2: opaque red, opaque green, half-transparent blue, fully transparent
        Raster::from_rgba(2, 2, vec![255, 0, 0, 255, 0, 255, 0, 255, 0, 0, 255, 128, 0, 0, 0, 0]).unwrap()
    }

    #[test]
    fn png_with_alpha_round_trips_exactly() {
        let r = sample();
        let bytes = encode(&r, ExportFormat::PngTransparent).unwrap();
        assert_eq!(&bytes[1..4], b"PNG");
        assert_eq!(dimensions(&bytes).unwrap(), (2, 2));
        let back = decode_image(&bytes).unwrap();
        assert_eq!(back.w, 2);
        // visible pixels survive exactly; the transparent one keeps alpha 0
        assert_eq!(&back.px[0..8], &r.px[0..8]);
        assert_eq!(&back.px[8..12], &r.px[8..12]);
        assert_eq!(back.px[15], 0);
    }

    #[test]
    fn jpeg_is_a_jpeg_with_the_right_size() {
        let bytes = encode(&sample(), ExportFormat::Jpeg { quality: 90, flatten_over: Rgba::WHITE }).unwrap();
        assert_eq!(&bytes[0..2], &[0xFF, 0xD8]);
        assert_eq!(dimensions(&bytes).unwrap(), (2, 2));
        assert!(decode_image(&bytes).is_ok());
    }

    #[test]
    fn flatten_blends_over_the_given_colour() {
        let rgb = flatten(&sample(), Rgba([255, 255, 255, 255]));
        assert_eq!(&rgb[0..3], &[255, 0, 0]);
        assert_eq!(&rgb[9..12], &[255, 255, 255]); // transparent -> background
        assert_eq!(rgb[8], 255); // half blue over white keeps blue high
        assert!(rgb[6] > 100 && rgb[6] < 160); // and red/green about half
    }

    #[test]
    fn garbage_is_an_error() {
        assert!(matches!(decode_image(b"not an image"), Err(IoError::Decode(_))));
    }
}
