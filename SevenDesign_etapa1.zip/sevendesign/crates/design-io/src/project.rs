//! A Seven Design project is a folder:
//!
//! ```text
//! MyDesign.sevend/
//!   document.json        the document (versioned JSON, see sevendesign_doc::FORMAT_VERSION)
//!   document.json.bak    the previous save, used if document.json is damaged
//!   assets/<id>.<ext>    the imported pictures, byte for byte as they were imported
//!   fonts/<n>-<name>     the TTF/OTF files the user added, registered again on open
//! ```

use std::collections::HashSet;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use sevendesign_doc::{Background, Document, Editor, LayerId, Rgba};
use sevendesign_render::Renderer;

use crate::codec::{ExportFormat, decode_image, dimensions, encode};
use crate::store::AssetStore;
use crate::IoError;

const DOC_FILE: &str = "document.json";
const BAK_FILE: &str = "document.json.bak";
/// Decoded-picture cache, in bytes.
const CACHE_BUDGET: usize = 256 * 1024 * 1024;

pub struct Project {
    pub dir: PathBuf,
    pub editor: Editor,
    pub store: Arc<AssetStore>,
    pub renderer: Arc<Renderer>,
    /// True when `open` had to fall back to the backup because `document.json` was unreadable.
    pub recovered_from_backup: bool,
}

fn image_ext(bytes: &[u8]) -> Option<&'static str> {
    if bytes.starts_with(&[0x89, b'P', b'N', b'G']) {
        Some("png")
    } else if bytes.starts_with(&[0xFF, 0xD8, 0xFF]) {
        Some("jpg")
    } else {
        None
    }
}

fn safe_name(name: &str) -> String {
    let cleaned: String = name.chars().map(|c| if c.is_ascii_alphanumeric() || c == '.' || c == '-' || c == '_' { c } else { '_' }).collect();
    let cleaned = cleaned.trim_matches('.');
    if cleaned.is_empty() { "font".to_string() } else { cleaned.chars().take(60).collect() }
}

impl Project {
    /// Creates the folder and its first save.
    pub fn create(dir: &Path, doc: Document) -> Result<Project, IoError> {
        std::fs::create_dir_all(dir.join("assets"))?;
        std::fs::create_dir_all(dir.join("fonts"))?;
        let mut p = Project::wrap(dir, doc, false);
        p.save()?;
        Ok(p)
    }

    fn wrap(dir: &Path, doc: Document, recovered: bool) -> Project {
        let store = Arc::new(AssetStore::new(dir.to_path_buf(), CACHE_BUDGET));
        for a in &doc.assets {
            store.register(a.id, &a.file);
        }
        Project { dir: dir.to_path_buf(), editor: Editor::new(doc), store, renderer: Arc::new(Renderer::new()), recovered_from_backup: recovered }
    }

    /// Opens a project: `document.json`, or the backup if that cannot be read; then registers
    /// the project's fonts.
    pub fn open(dir: &Path) -> Result<Project, IoError> {
        let read = |name: &str| -> Result<Document, IoError> { Ok(Document::from_json(&std::fs::read_to_string(dir.join(name))?)?) };
        let (doc, recovered) = match read(DOC_FILE) {
            Ok(d) => (d, false),
            // a newer-format file is not "damaged": do not replace it with an older backup
            Err(IoError::Doc(sevendesign_doc::DocError::TooNew(v))) => return Err(IoError::Doc(sevendesign_doc::DocError::TooNew(v))),
            Err(first) => match read(BAK_FILE) {
                Ok(d) => (d, true),
                Err(_) => return Err(first),
            },
        };
        let project = Project::wrap(dir, doc, recovered);
        project.register_fonts();
        Ok(project)
    }

    fn register_fonts(&self) {
        let Ok(rd) = std::fs::read_dir(self.dir.join("fonts")) else { return };
        let mut files: Vec<_> = rd.flatten().map(|e| e.path()).filter(|p| p.is_file()).collect();
        files.sort();
        for f in files {
            if let Ok(data) = std::fs::read(&f) {
                filmcraft_text::fonts::add_font_data(data);
            }
        }
    }

    /// Saves atomically: the new file is written and synced beside the old one, the old one
    /// becomes `.bak`, then the new one takes its place. A crash leaves one of the two intact.
    pub fn save(&mut self) -> Result<(), IoError> {
        let json = self.editor.doc().to_json()?;
        let tmp = self.dir.join("document.json.tmp");
        {
            let mut f = std::fs::File::create(&tmp)?;
            f.write_all(json.as_bytes())?;
            f.sync_all()?;
        }
        let doc_path = self.dir.join(DOC_FILE);
        if doc_path.exists() {
            let bak = self.dir.join(BAK_FILE);
            let _ = std::fs::remove_file(&bak);
            std::fs::rename(&doc_path, &bak)?;
        }
        std::fs::rename(&tmp, &doc_path)?;
        self.editor.mark_saved();
        Ok(())
    }

    /// Imports a PNG or JPEG as a new top layer (one undo step). The original bytes are kept.
    pub fn import_image(&mut self, name: &str, bytes: &[u8]) -> Result<LayerId, IoError> {
        let ext = image_ext(bytes).ok_or_else(|| IoError::Decode("only PNG and JPEG pictures can be imported".into()))?;
        let (w, h) = dimensions(bytes)?;
        // Full decode check: a truncated file is refused now, not when it first renders.
        decode_image(bytes)?;
        let id = self.editor.doc().next_id;
        let file = format!("assets/{id}.{ext}");
        std::fs::create_dir_all(self.dir.join("assets"))?;
        std::fs::write(self.dir.join(&file), bytes)?;
        let (asset, layer) = self.editor.import_image(name, &file, w, h);
        self.store.register(asset, &file);
        Ok(layer)
    }

    /// Adds a TTF/OTF font to the project; returns its `family / style` names (usable in text
    /// layers straight away).
    pub fn import_font(&mut self, file_name: &str, data: Vec<u8>) -> Result<Vec<String>, IoError> {
        let ids = filmcraft_text::fonts::add_font_data(data.clone());
        if ids.is_empty() {
            return Err(IoError::BadFont);
        }
        let dir = self.dir.join("fonts");
        std::fs::create_dir_all(&dir)?;
        let n = std::fs::read_dir(&dir).map(|rd| rd.count()).unwrap_or(0);
        std::fs::write(dir.join(format!("{n:03}-{}", safe_name(file_name))), &data)?;
        let mut seen = HashSet::new();
        Ok(ids
            .into_iter()
            .map(|id| {
                let f = filmcraft_text::fonts::face(id);
                format!("{} / {}", f.info.family, f.info.style)
            })
            .filter(|s| seen.insert(s.clone()))
            .collect())
    }

    /// Pictures the document refers to whose file is not on disk.
    pub fn missing_assets(&self) -> Vec<String> {
        self.editor.doc().assets.iter().filter(|a| !self.store.exists(a.id)).map(|a| a.name.clone()).collect()
    }

    /// Renders the whole canvas at `scale` and encodes it.
    pub fn export(&self, format: ExportFormat, scale: f32) -> Result<Vec<u8>, IoError> {
        let raster = self.renderer.render_full(self.editor.doc(), &*self.store, scale)?;
        encode(&raster, format)
    }

    /// The colour flattened formats (JPEG, PNG without alpha) are laid over; see [`flatten_color`].
    pub fn flatten_color(&self) -> Rgba {
        flatten_color(self.editor.doc())
    }
}

/// The colour a flattened export is laid over: the canvas colour when it is opaque, else white.
pub fn flatten_color(doc: &Document) -> Rgba {
    match doc.background {
        Background::Solid(c) if c.0[3] == 255 => c,
        _ => Rgba::WHITE,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use sevendesign_doc::{Background, TextContent, Transform};
    use sevendesign_render::Raster;

    fn png(w: u32, h: u32, c: [u8; 4]) -> Vec<u8> {
        let r = Raster::from_rgba(w, h, c.iter().copied().cycle().take((w * h * 4) as usize).collect()).unwrap();
        encode(&r, ExportFormat::PngTransparent).unwrap()
    }

    fn new_project(dir: &Path, w: u32, h: u32, bg: Background) -> Project {
        Project::create(&dir.join("p.sevend"), Document::new("p", w, h, 72.0, bg).unwrap()).unwrap()
    }

    #[test]
    fn create_save_open_round_trip() {
        let tmp = tempfile::tempdir().unwrap();
        let mut p = new_project(tmp.path(), 200, 100, Background::Solid(Rgba([1, 2, 3, 255])));
        let layer = p.import_image("foto", &png(10, 10, [255, 0, 0, 255])).unwrap();
        p.editor.add_text_layer(TextContent { text: "Hola".into(), ..Default::default() });
        p.save().unwrap();
        let q = Project::open(&p.dir).unwrap();
        assert!(!q.recovered_from_backup);
        assert_eq!(q.editor.doc(), p.editor.doc());
        assert!(q.editor.doc().layer(layer).is_some());
        assert!(q.missing_assets().is_empty());
    }

    #[test]
    fn a_damaged_document_falls_back_to_the_backup() {
        let tmp = tempfile::tempdir().unwrap();
        let mut p = new_project(tmp.path(), 50, 50, Background::Transparent);
        p.editor.add_text_layer(TextContent { text: "uno".into(), ..Default::default() });
        p.save().unwrap(); // the first save becomes the .bak of this one
        p.editor.add_text_layer(TextContent { text: "dos".into(), ..Default::default() });
        p.save().unwrap();
        std::fs::write(p.dir.join(DOC_FILE), "{ truncated").unwrap();
        let q = Project::open(&p.dir).unwrap();
        assert!(q.recovered_from_backup);
        assert_eq!(q.editor.doc().layers.len(), 1);
    }

    #[test]
    fn a_newer_format_is_refused_not_replaced_by_the_backup() {
        let tmp = tempfile::tempdir().unwrap();
        let mut p = new_project(tmp.path(), 50, 50, Background::Transparent);
        p.save().unwrap();
        let mut d = p.editor.doc().clone();
        d.version = 99;
        std::fs::write(p.dir.join(DOC_FILE), serde_json_string(&d)).unwrap();
        assert!(matches!(Project::open(&p.dir), Err(IoError::Doc(sevendesign_doc::DocError::TooNew(99)))));
    }

    fn serde_json_string(d: &Document) -> String {
        d.to_json().unwrap().replacen("\"version\": 1", "\"version\": 99", 1)
    }

    #[test]
    fn importing_rejects_non_images_and_bad_files() {
        let tmp = tempfile::tempdir().unwrap();
        let mut p = new_project(tmp.path(), 50, 50, Background::Transparent);
        assert!(p.import_image("x", b"GIF89a....").is_err());
        let mut truncated = png(20, 20, [1, 2, 3, 255]);
        truncated.truncate(truncated.len() / 2);
        assert!(p.import_image("x", &truncated).is_err());
        assert!(p.editor.doc().layers.is_empty() && p.editor.doc().assets.is_empty());
    }

    #[test]
    fn export_png_and_jpg_have_the_canvas_size_and_content() {
        let tmp = tempfile::tempdir().unwrap();
        let mut p = new_project(tmp.path(), 40, 30, Background::Transparent);
        let id = p.import_image("rojo", &png(4, 4, [255, 0, 0, 255])).unwrap();
        p.editor.set_transform(id, Transform { cx: 20.0, cy: 15.0, scale_x: 10.0, scale_y: 7.0, rotation_deg: 0.0 }).unwrap();

        let bytes = p.export(ExportFormat::PngTransparent, 1.0).unwrap();
        let img = decode_image(&bytes).unwrap();
        assert_eq!((img.w, img.h), (40, 30));
        let at = |x: u32, y: u32| {
            let i = ((y * img.w + x) * 4) as usize;
            [img.px[i], img.px[i + 1], img.px[i + 2], img.px[i + 3]]
        };
        assert_eq!(at(20, 15), [255, 0, 0, 255]);
        assert_eq!(at(0, 0)[3], 0); // transparent canvas stays transparent outside the picture

        let jpg = p.export(ExportFormat::Jpeg { quality: 95, flatten_over: p.flatten_color() }, 2.0).unwrap();
        assert_eq!(&jpg[0..2], &[0xFF, 0xD8]);
        assert_eq!(dimensions(&jpg).unwrap(), (80, 60));
    }

    #[test]
    fn a_picture_missing_on_disk_is_reported_and_skipped() {
        let tmp = tempfile::tempdir().unwrap();
        let mut p = new_project(tmp.path(), 40, 30, Background::Transparent);
        p.import_image("foto", &png(4, 4, [0, 255, 0, 255])).unwrap();
        p.save().unwrap();
        std::fs::remove_dir_all(p.dir.join("assets")).unwrap();
        let q = Project::open(&p.dir).unwrap();
        assert_eq!(q.missing_assets(), vec!["foto".to_string()]);
        assert!(q.export(ExportFormat::PngTransparent, 1.0).is_ok());
    }

    #[test]
    fn bad_font_data_is_refused() {
        let tmp = tempfile::tempdir().unwrap();
        let mut p = new_project(tmp.path(), 10, 10, Background::Transparent);
        assert!(matches!(p.import_font("x.ttf", b"not a font".to_vec()), Err(IoError::BadFont)));
    }

    #[test]
    fn a_bundled_font_file_can_be_imported_and_persisted() {
        let tmp = tempfile::tempdir().unwrap();
        let mut p = new_project(tmp.path(), 10, 10, Background::Transparent);
        let ttf = std::fs::read(concat!(env!("CARGO_MANIFEST_DIR"), "/../../assets/fonts/NotoSerif-Regular.ttf")).unwrap();
        let names = p.import_font("NotoSerif-Regular.ttf", ttf).unwrap();
        assert!(!names.is_empty());
        assert_eq!(std::fs::read_dir(p.dir.join("fonts")).unwrap().count(), 1);
    }
}
