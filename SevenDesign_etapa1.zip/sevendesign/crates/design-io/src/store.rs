use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, PoisonError};

use sevendesign_doc::AssetId;
use sevendesign_render::{AssetSource, Raster};

use crate::codec::decode_image;

/// Smallest mip level kept: 1/64 of the picture's size per side.
const MAX_LEVEL: u32 = 6;

struct Entry {
    raster: Arc<Raster>,
    used: u64,
}

#[derive(Default)]
struct Cache {
    map: HashMap<(AssetId, u32), Entry>,
    tick: u64,
    bytes: usize,
}

/// The renderer's picture source. Files stay on disk; a picture is decoded when first needed and
/// only the mip level the view asks for stays cached, within `budget` bytes (least recently used
/// out first). Zoomed out on a 50-photo document, memory holds small copies, not 50 full photos.
pub struct AssetStore {
    root: PathBuf,
    files: Mutex<HashMap<AssetId, String>>,
    cache: Mutex<Cache>,
    budget: usize,
}

impl AssetStore {
    pub fn new(root: PathBuf, budget_bytes: usize) -> Self {
        Self { root, files: Mutex::new(HashMap::new()), cache: Mutex::new(Cache::default()), budget: budget_bytes }
    }

    /// Tells the store where picture `id` lives (path relative to the project folder).
    pub fn register(&self, id: AssetId, file: &str) {
        self.files.lock().unwrap_or_else(PoisonError::into_inner).insert(id, file.to_string());
    }

    /// Whether the file of `id` is on disk.
    pub fn exists(&self, id: AssetId) -> bool {
        self.path(id).is_some_and(|p| p.is_file())
    }

    /// Drops cached copies of `id` (after its file changed or was removed).
    pub fn invalidate(&self, id: AssetId) {
        let mut c = self.cache.lock().unwrap_or_else(PoisonError::into_inner);
        let keys: Vec<_> = c.map.keys().filter(|k| k.0 == id).copied().collect();
        for k in keys {
            if let Some(e) = c.map.remove(&k) {
                c.bytes = c.bytes.saturating_sub(e.raster.bytes());
            }
        }
    }

    /// Bytes currently cached (for tests and diagnostics).
    pub fn cached_bytes(&self) -> usize {
        self.cache.lock().unwrap_or_else(PoisonError::into_inner).bytes
    }

    fn path(&self, id: AssetId) -> Option<PathBuf> {
        self.files.lock().unwrap_or_else(PoisonError::into_inner).get(&id).map(|f| self.root.join(f))
    }

    /// Mip level whose size is still at least what the view needs (0 = full size).
    pub fn level_for(wanted_scale: f32) -> u32 {
        if !wanted_scale.is_finite() || wanted_scale >= 1.0 || wanted_scale <= 0.0 {
            return if wanted_scale > 0.0 { 0 } else { MAX_LEVEL };
        }
        ((1.0 / wanted_scale).log2().floor().max(0.0) as u32).min(MAX_LEVEL)
    }

    fn touch(&self, id: AssetId, level: u32) -> Option<Arc<Raster>> {
        let mut c = self.cache.lock().unwrap_or_else(PoisonError::into_inner);
        c.tick += 1;
        let tick = c.tick;
        c.map.get_mut(&(id, level)).map(|e| {
            e.used = tick;
            e.raster.clone()
        })
    }

    /// Highest cached level below `level`, as a starting point for a smaller one.
    fn best_source(&self, id: AssetId, level: u32) -> Option<(u32, Arc<Raster>)> {
        let c = self.cache.lock().unwrap_or_else(PoisonError::into_inner);
        (0..level).rev().find_map(|l| c.map.get(&(id, l)).map(|e| (l, e.raster.clone())))
    }

    fn insert(&self, id: AssetId, level: u32, raster: Arc<Raster>) {
        let mut c = self.cache.lock().unwrap_or_else(PoisonError::into_inner);
        c.tick += 1;
        let tick = c.tick;
        c.bytes += raster.bytes();
        if let Some(old) = c.map.insert((id, level), Entry { raster, used: tick }) {
            c.bytes = c.bytes.saturating_sub(old.raster.bytes());
        }
        while c.bytes > self.budget && c.map.len() > 1 {
            let Some(oldest) = c.map.iter().filter(|(k, _)| **k != (id, level)).min_by_key(|(_, e)| e.used).map(|(k, _)| *k) else { break };
            if let Some(e) = c.map.remove(&oldest) {
                c.bytes = c.bytes.saturating_sub(e.raster.bytes());
            }
        }
    }
}

impl AssetSource for AssetStore {
    fn load(&self, id: AssetId, wanted_scale: f32) -> Option<Arc<Raster>> {
        let level = Self::level_for(wanted_scale);
        if let Some(r) = self.touch(id, level) {
            return Some(r);
        }
        // Start from the closest bigger copy in the cache, else decode the file.
        let (mut at, mut raster) = match self.best_source(id, level) {
            Some(found) => found,
            None => {
                let bytes = std::fs::read(self.path(id)?).ok()?;
                (0, Arc::new(decode_image(&bytes).ok()?))
            }
        };
        while at < level && raster.w > 1 && raster.h > 1 {
            raster = Arc::new(raster.downscale_half());
            at += 1;
        }
        // `at` can stop short of `level` for a tiny picture: it is cached under the level asked.
        self.insert(id, level, raster.clone());
        Some(raster)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::codec::{ExportFormat, encode};
    use sevendesign_doc::Rgba;

    fn write_png(dir: &std::path::Path, name: &str, w: u32, h: u32) {
        let r = Raster::from_rgba(w, h, [10u8, 20, 30, 255].iter().copied().cycle().take((w * h * 4) as usize).collect()).unwrap();
        std::fs::write(dir.join(name), encode(&r, ExportFormat::Png { flatten_over: Rgba::WHITE }).unwrap()).unwrap();
    }

    #[test]
    fn levels_follow_the_view_scale() {
        assert_eq!(AssetStore::level_for(2.0), 0);
        assert_eq!(AssetStore::level_for(1.0), 0);
        assert_eq!(AssetStore::level_for(0.7), 0);
        assert_eq!(AssetStore::level_for(0.5), 1);
        assert_eq!(AssetStore::level_for(0.3), 1);
        assert_eq!(AssetStore::level_for(0.125), 3);
        assert_eq!(AssetStore::level_for(0.0001), 6);
    }

    #[test]
    fn zoomed_out_keeps_a_small_copy() {
        let dir = tempfile::tempdir().unwrap();
        write_png(dir.path(), "a.png", 64, 32);
        let s = AssetStore::new(dir.path().to_path_buf(), 1 << 20);
        s.register(1, "a.png");
        let small = s.load(1, 0.25).unwrap();
        assert_eq!((small.w, small.h), (16, 8));
        assert_eq!(s.cached_bytes(), 16 * 8 * 4); // only the small level is held
        let full = s.load(1, 1.0).unwrap();
        assert_eq!((full.w, full.h), (64, 32));
    }

    #[test]
    fn the_budget_evicts_least_recently_used() {
        let dir = tempfile::tempdir().unwrap();
        for n in ["a.png", "b.png", "c.png"] {
            write_png(dir.path(), n, 32, 32); // 4096 bytes each
        }
        let s = AssetStore::new(dir.path().to_path_buf(), 9000); // room for two
        for (i, n) in ["a.png", "b.png", "c.png"].iter().enumerate() {
            s.register(i as u64 + 1, n);
        }
        s.load(1, 1.0).unwrap();
        s.load(2, 1.0).unwrap();
        s.load(1, 1.0).unwrap(); // a is now more recent than b
        s.load(3, 1.0).unwrap(); // evicts b
        assert!(s.cached_bytes() <= 9000);
        assert!(s.touch(1, 0).is_some() && s.touch(3, 0).is_some());
        assert!(s.touch(2, 0).is_none());
    }

    #[test]
    fn unknown_or_missing_files_give_none() {
        let dir = tempfile::tempdir().unwrap();
        let s = AssetStore::new(dir.path().to_path_buf(), 1 << 20);
        assert!(s.load(9, 1.0).is_none());
        s.register(9, "gone.png");
        assert!(s.load(9, 1.0).is_none());
        assert!(!s.exists(9));
    }
}
