/// Straight (non-premultiplied) sRGB RGBA8, row-major.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Raster {
    pub w: u32,
    pub h: u32,
    pub px: Vec<u8>,
}

impl Raster {
    /// A transparent raster. Sizes whose buffer would not fit in memory give an empty one.
    pub fn new(w: u32, h: u32) -> Self {
        let len = (w as usize).checked_mul(h as usize).and_then(|n| n.checked_mul(4));
        let mut px = Vec::new();
        match len {
            Some(len) if px.try_reserve_exact(len).is_ok() => {
                px.resize(len, 0);
                Self { w, h, px }
            }
            _ => Self { w: 0, h: 0, px: Vec::new() },
        }
    }

    /// Wraps existing pixels; `None` if the length is not `w * h * 4`.
    pub fn from_rgba(w: u32, h: u32, px: Vec<u8>) -> Option<Self> {
        ((w as usize).checked_mul(h as usize)?.checked_mul(4)? == px.len()).then_some(Self { w, h, px })
    }

    /// Memory held by the pixels.
    pub fn bytes(&self) -> usize {
        self.px.len()
    }

    /// Half-size copy (box filter on premultiplied colour, so transparent edges don't darken).
    pub fn downscale_half(&self) -> Raster {
        let (nw, nh) = ((self.w / 2).max(1), (self.h / 2).max(1));
        let mut out = Raster::new(nw, nh);
        if self.w == 0 || self.h == 0 || out.w == 0 {
            return out;
        }
        for y in 0..nh {
            for x in 0..nw {
                let mut sum = [0u32; 3];
                let mut sa = 0u32;
                let mut n = 0u32;
                for (dx, dy) in [(0, 0), (1, 0), (0, 1), (1, 1)] {
                    let sx = (x * 2 + dx).min(self.w - 1);
                    let sy = (y * 2 + dy).min(self.h - 1);
                    let i = ((sy * self.w + sx) * 4) as usize;
                    let a = u32::from(self.px[i + 3]);
                    for c in 0..3 {
                        sum[c] += u32::from(self.px[i + c]) * a;
                    }
                    sa += a;
                    n += 1;
                }
                let o = ((y * nw + x) * 4) as usize;
                if sa > 0 {
                    for c in 0..3 {
                        out.px[o + c] = ((sum[c] + sa / 2) / sa).min(255) as u8;
                    }
                }
                out.px[o + 3] = ((sa + n / 2) / n).min(255) as u8;
            }
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn from_rgba_checks_length() {
        assert!(Raster::from_rgba(2, 2, vec![0; 16]).is_some());
        assert!(Raster::from_rgba(2, 2, vec![0; 15]).is_none());
    }

    #[test]
    fn downscale_keeps_colour_next_to_transparency() {
        // left column opaque red, right column fully transparent
        let mut r = Raster::new(2, 2);
        for y in 0..2 {
            let i = (y * 2) * 4;
            r.px[i..i + 4].copy_from_slice(&[255, 0, 0, 255]);
        }
        let d = r.downscale_half();
        assert_eq!((d.w, d.h), (1, 1));
        assert_eq!(&d.px[0..3], &[255, 0, 0]); // not darkened by the transparent pixels
        assert_eq!(d.px[3], 128);
    }

    #[test]
    fn downscale_of_one_pixel_stays_one_pixel() {
        let r = Raster::from_rgba(1, 1, vec![9, 8, 7, 255]).unwrap();
        assert_eq!(r.downscale_half().px, vec![9, 8, 7, 255]);
    }
}
