//! Seven Design compositor.
//!
//! - [`Raster`]: straight sRGB RGBA8 pixels (what layers, the screen and the export use).
//! - [`AssetSource`]: how the renderer gets a picture's pixels, at the size it needs (the store
//!   in `sevendesign-io` keeps a small mip chain, so zoomed-out views never hold full photos).
//! - [`Renderer::render_region`]: any rectangle of the canvas at any scale (the on-screen view).
//! - [`Renderer::render_full`]: the whole canvas in 512 px tiles (the export).
//!
//! Compositing happens in sRGB-encoded space on premultiplied f32, the way Photoshop blends by
//! default (Seven Cut Pro's compositor works in linear light, which is right for video but makes
//! Multiply/Overlay look different from what designers expect).

mod compose;
mod raster;
mod text;

pub use compose::{AssetSource, IRect, RenderError, Renderer};
pub use raster::Raster;
