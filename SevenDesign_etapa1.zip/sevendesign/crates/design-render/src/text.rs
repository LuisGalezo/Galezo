//! Text layers become pictures: shaped and rasterised by the vendored `filmcraft-text` engine
//! (kerning, ligatures, bidi, user fonts), then composited like any other layer.

use filmcraft_text as ft;
use sevendesign_doc::{TextAlign, TextContent};

use crate::raster::Raster;

/// Longest side of a rasterised text layer; anything beyond is cut off.
const MAX_SIDE: u32 = 8192;
/// Transparent margin around the text, in layer pixels (at `k` = 1), for soft edges.
const PAD: f32 = 2.0;

/// Rasterises `c` with every length multiplied by `k` (k = 1 is the layer's natural size).
pub fn rasterize_text(c: &TextContent, k: f32) -> Raster {
    let k = k.clamp(0.05, 8.0);
    let style = ft::TextStyle {
        family: c.family.clone(),
        style: c.style.clone(),
        size: (c.size_px * k).clamp(1.0, 4096.0),
        tracking: c.tracking,
        ..Default::default()
    };
    let align = match c.align {
        TextAlign::Left => ft::Align::Left,
        TextAlign::Center => ft::Align::Center,
        TextAlign::Right => ft::Align::Right,
    };
    let para = ft::ParagraphStyle { align, leading: c.leading * k, width: c.box_width.map(|w| (w * k).max(1.0)), ..Default::default() };
    let layout = ft::layout(&c.text, &style, &para);
    let b = layout.bounds;
    let pad = PAD * k;
    let w = (((b[2] - b[0]).max(0.0).ceil() + 2.0 * pad).ceil() as u32).clamp(1, MAX_SIDE);
    let h = (((b[3] - b[1]).max(0.0).ceil() + 2.0 * pad).ceil() as u32).clamp(1, MAX_SIDE);
    let mut out = Raster::new(w, h);
    if out.w == 0 {
        return out;
    }
    let xf = ft::render::at(pad - b[0], pad - b[1]);
    let (mask, mx, my) = ft::render::rasterize(&layout, &xf);
    let [r, g, bl, ca] = c.color.0;
    for y in 0..mask.h {
        let dy = my + y as i32;
        if dy < 0 || dy >= out.h as i32 {
            continue;
        }
        for x in 0..mask.w {
            let dx = mx + x as i32;
            if dx < 0 || dx >= out.w as i32 {
                continue;
            }
            let cov = mask.a[y * mask.w + x].clamp(0.0, 1.0);
            if cov <= 0.0 {
                continue;
            }
            let i = ((dy as u32 * out.w + dx as u32) * 4) as usize;
            out.px[i] = r;
            out.px[i + 1] = g;
            out.px[i + 2] = bl;
            out.px[i + 3] = (cov * f32::from(ca)).round().clamp(0.0, 255.0) as u8;
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use sevendesign_doc::Rgba;

    #[test]
    fn text_has_ink_in_the_requested_colour() {
        let c = TextContent { text: "Hola".into(), size_px: 64.0, color: Rgba([200, 10, 30, 255]), ..Default::default() };
        let r = rasterize_text(&c, 1.0);
        assert!(r.w > 20 && r.h > 20);
        let inked: Vec<_> = r.px.chunks_exact(4).filter(|p| p[3] == 255).collect();
        assert!(!inked.is_empty());
        assert!(inked.iter().all(|p| p[0] == 200 && p[1] == 10 && p[2] == 30));
    }

    #[test]
    fn bigger_k_gives_a_bigger_raster() {
        let c = TextContent { text: "Hola".into(), size_px: 40.0, ..Default::default() };
        let (a, b) = (rasterize_text(&c, 1.0), rasterize_text(&c, 2.0));
        assert!(b.w as f32 > a.w as f32 * 1.8 && (b.w as f32) < a.w as f32 * 2.2);
    }

    #[test]
    fn empty_text_is_a_small_transparent_raster() {
        let r = rasterize_text(&TextContent::default(), 1.0);
        assert!(r.w >= 1 && r.h >= 1);
        assert!(r.px.chunks_exact(4).all(|p| p[3] == 0));
    }
}
