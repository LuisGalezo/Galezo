use std::collections::HashMap;
use std::sync::{Arc, Mutex, PoisonError};

use rayon::prelude::*;
use sevendesign_doc::{AssetId, Background, BlendMode, Document, Layer, LayerId, LayerKind, Transform};

use crate::raster::Raster;
use crate::text::rasterize_text;

/// Export tile side in pixels.
const TILE: u32 = 512;
/// Most pixels one rendered region may have (RGBA8 = 4 bytes each, plus 16 per pixel while compositing).
const MAX_REGION_PIXELS: u64 = 64_000_000;
/// Most pixels a full export may have.
const MAX_EXPORT_PIXELS: u64 = 100_000_000;
/// Rasterised text variants kept (one per text layer and size step).
const TEXT_CACHE_MAX: usize = 48;

#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum RenderError {
    #[error("output of {0}x{1} pixels is too large")]
    TooLarge(u32, u32),
}

/// Where the renderer gets a picture's pixels.
pub trait AssetSource: Send + Sync {
    /// Pixels of `id`. `wanted_scale` is how many output pixels each source pixel covers
    /// (below 1 = shown smaller than its size): the source may answer with a smaller copy
    /// (any size; the renderer maps by proportion). `None` = unavailable (the layer is skipped).
    fn load(&self, id: AssetId, wanted_scale: f32) -> Option<Arc<Raster>>;
}

/// A rectangle of output pixels.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct IRect {
    pub x: i32,
    pub y: i32,
    pub w: u32,
    pub h: u32,
}

#[derive(Default)]
pub struct Renderer {
    text_cache: Mutex<HashMap<(String, i32), Arc<Raster>>>,
}

impl Renderer {
    pub fn new() -> Self {
        Self::default()
    }

    /// Rasterised text at size step `step` (k = 2^(step/2)); cached.
    fn text_raster(&self, layer: &Layer, step: i32) -> Option<Arc<Raster>> {
        let LayerKind::Text(content) = &layer.kind else { return None };
        let key = (format!("{content:?}"), step);
        if let Some(r) = self.text_cache.lock().unwrap_or_else(PoisonError::into_inner).get(&key) {
            return Some(r.clone());
        }
        let r = Arc::new(rasterize_text(content, 2f32.powf(step as f32 / 2.0)));
        let mut cache = self.text_cache.lock().unwrap_or_else(PoisonError::into_inner);
        if cache.len() >= TEXT_CACHE_MAX {
            cache.clear();
        }
        cache.insert(key, r.clone());
        Some(r)
    }

    /// The layer's natural size in canvas pixels (a picture's pixel size, a text's laid-out size).
    pub fn layer_size(&self, layer: &Layer) -> Option<(u32, u32)> {
        match &layer.kind {
            LayerKind::Image { width, height, .. } => Some((*width, *height)),
            LayerKind::Text(_) => self.text_raster(layer, 0).map(|r| (r.w, r.h)),
        }
    }

    /// Topmost visible layer whose box contains the canvas point `(x, y)`.
    pub fn hit_test(&self, doc: &Document, x: f64, y: f64) -> Option<LayerId> {
        doc.layers.iter().rev().filter(|l| l.visible).find_map(|l| {
            let (lw, lh) = self.layer_size(l)?;
            let (u, v) = to_local(&l.transform, f64::from(lw), f64::from(lh), x, y)?;
            (u >= 0.0 && v >= 0.0 && u <= f64::from(lw) && v <= f64::from(lh)).then_some(l.id)
        })
    }

    /// The four corners of a layer's box on the canvas (for selection handles), clockwise from
    /// the top-left.
    pub fn layer_corners(&self, layer: &Layer) -> Option<[(f64, f64); 4]> {
        let (lw, lh) = self.layer_size(layer)?;
        Some(corners(&layer.transform, f64::from(lw), f64::from(lh)))
    }

    /// Renders `region` of the canvas shown at `scale` output pixels per canvas pixel (pixel
    /// `(0, 0)` of the result is output pixel `(region.x, region.y)`). A region too large to
    /// hold gives an empty raster.
    pub fn render_region(&self, doc: &Document, assets: &dyn AssetSource, region: IRect, scale: f32) -> Raster {
        let scale = scale.clamp(0.001, 64.0);
        let (w, h) = (region.w as usize, region.h as usize);
        if u64::from(region.w) * u64::from(region.h) > MAX_REGION_PIXELS {
            return Raster::new(0, 0);
        }
        if w == 0 || h == 0 {
            return Raster::new(region.w, region.h);
        }
        let mut acc = vec![0.0f32; w * h * 4];
        if let Background::Solid(c) = doc.background {
            let a = f32::from(c.0[3]) / 255.0;
            let px = [f32::from(c.0[0]) / 255.0 * a, f32::from(c.0[1]) / 255.0 * a, f32::from(c.0[2]) / 255.0 * a, a];
            for p in acc.chunks_exact_mut(4) {
                p.copy_from_slice(&px);
            }
        }
        for layer in doc.layers.iter().filter(|l| l.visible && l.opacity > 0.0) {
            self.draw_layer(&mut acc, w, h, layer, assets, region, scale);
        }
        let mut out = Raster::new(region.w, region.h);
        for (o, p) in out.px.chunks_exact_mut(4).zip(acc.chunks_exact(4)) {
            let a = p[3];
            if a > 0.0 {
                for c in 0..3 {
                    o[c] = (p[c] / a * 255.0).round().clamp(0.0, 255.0) as u8;
                }
                o[3] = (a * 255.0).round().clamp(0.0, 255.0) as u8;
            }
        }
        out
    }

    /// The whole canvas at `scale`, rendered tile by tile.
    pub fn render_full(&self, doc: &Document, assets: &dyn AssetSource, scale: f32) -> Result<Raster, RenderError> {
        let scale = scale.clamp(0.001, 64.0);
        let ow = (f64::from(doc.width) * f64::from(scale)).round().max(1.0);
        let oh = (f64::from(doc.height) * f64::from(scale)).round().max(1.0);
        if ow * oh > MAX_EXPORT_PIXELS as f64 || ow > f64::from(u32::MAX) || oh > f64::from(u32::MAX) {
            return Err(RenderError::TooLarge(ow.min(f64::from(u32::MAX)) as u32, oh.min(f64::from(u32::MAX)) as u32));
        }
        let (ow, oh) = (ow as u32, oh as u32);
        let mut out = Raster::new(ow, oh);
        if out.w == 0 {
            return Err(RenderError::TooLarge(ow, oh));
        }
        let mut ty = 0;
        while ty < oh {
            let th = TILE.min(oh - ty);
            let mut tx = 0;
            while tx < ow {
                let tw = TILE.min(ow - tx);
                let tile = self.render_region(doc, assets, IRect { x: tx as i32, y: ty as i32, w: tw, h: th }, scale);
                if tile.w != tw {
                    return Err(RenderError::TooLarge(ow, oh));
                }
                for row in 0..th as usize {
                    let src = row * tw as usize * 4;
                    let dst = ((ty as usize + row) * ow as usize + tx as usize) * 4;
                    out.px[dst..dst + tw as usize * 4].copy_from_slice(&tile.px[src..src + tw as usize * 4]);
                }
                tx += tw;
            }
            ty += th;
        }
        Ok(out)
    }

    #[allow(clippy::too_many_arguments)]
    fn draw_layer(&self, acc: &mut [f32], w: usize, h: usize, layer: &Layer, assets: &dyn AssetSource, region: IRect, scale: f32) {
        let Some((lw, lh)) = self.layer_size(layer) else { return };
        let t = layer.transform;
        let (sx, sy) = (t.scale_x as f32, t.scale_y as f32);
        if lw == 0 || lh == 0 || sx.abs() < 1e-6 || sy.abs() < 1e-6 || !(t.cx.is_finite() && t.cy.is_finite() && t.rotation_deg.is_finite()) {
            return;
        }
        // Pixels for this layer, at the size the view needs.
        let device_per_source = scale * sx.abs().max(sy.abs());
        let raster = match &layer.kind {
            LayerKind::Image { asset, .. } => assets.load(*asset, device_per_source),
            LayerKind::Text(_) => {
                let step = (device_per_source.clamp(0.05, 8.0).log2() * 2.0).round() as i32;
                self.text_raster(layer, step)
            }
        };
        let Some(raster) = raster else { return };
        if raster.w == 0 || raster.h == 0 {
            return;
        }
        // Device-space bounding box of the rotated layer, clipped to the region.
        let cs = corners(&t, f64::from(lw), f64::from(lh));
        let (mut x0, mut y0, mut x1, mut y1) = (f64::MAX, f64::MAX, f64::MIN, f64::MIN);
        for (cx, cy) in cs {
            let (dx, dy) = (cx * f64::from(scale) - f64::from(region.x), cy * f64::from(scale) - f64::from(region.y));
            x0 = x0.min(dx);
            y0 = y0.min(dy);
            x1 = x1.max(dx);
            y1 = y1.max(dy);
        }
        let (bx0, by0) = ((x0.floor() - 1.0).max(0.0) as usize, (y0.floor() - 1.0).max(0.0) as usize);
        let (bx1, by1) = (((x1.ceil() + 1.0).max(0.0) as usize).min(w), ((y1.ceil() + 1.0).max(0.0) as usize).min(h));
        if bx0 >= bx1 || by0 >= by1 {
            return;
        }
        let (sin, cos) = (t.rotation_deg as f32).to_radians().sin_cos();
        let (cx, cy) = (t.cx as f32, t.cy as f32);
        let (lwf, lhf) = (lw as f32, lh as f32);
        let (rx, ry) = (raster.w as f32 / lwf, raster.h as f32 / lhf);
        let (kx, ky) = (scale * sx.abs(), scale * sy.abs());
        let opacity = layer.opacity.clamp(0.0, 1.0);
        let blend = layer.blend;
        let (ox, oy) = (region.x as f32, region.y as f32);
        let raster: &Raster = &raster;
        acc.par_chunks_mut(w * 4).enumerate().skip(by0).take(by1 - by0).for_each(|(y, row)| {
            let dy = (oy + y as f32 + 0.5) / scale - cy;
            for x in bx0..bx1 {
                let dx = (ox + x as f32 + 0.5) / scale - cx;
                let lx = dx * cos + dy * sin;
                let ly = -dx * sin + dy * cos;
                let u = lx / sx + lwf / 2.0;
                let v = ly / sy + lhf / 2.0;
                // Antialiased box edge: distance to the nearest edge in output pixels, half a
                // pixel either side of the edge ramps coverage 0..1.
                let cov = ((u.min(lwf - u) * kx + 0.5).clamp(0.0, 1.0)) * ((v.min(lhf - v) * ky + 0.5).clamp(0.0, 1.0));
                if cov <= 0.0 {
                    continue;
                }
                let s = sample(raster, u * rx, v * ry);
                if s[3] <= 0.0 {
                    continue;
                }
                let k = cov * opacity;
                let src = [s[0] * k, s[1] * k, s[2] * k, s[3] * k];
                blend_pixel(&mut row[x * 4..x * 4 + 4], src, blend);
            }
        });
    }
}

/// Canvas point -> layer-local pixel coordinates (`None` for a degenerate scale).
fn to_local(t: &Transform, lw: f64, lh: f64, x: f64, y: f64) -> Option<(f64, f64)> {
    if t.scale_x.abs() < 1e-9 || t.scale_y.abs() < 1e-9 {
        return None;
    }
    let (sin, cos) = t.rotation_deg.to_radians().sin_cos();
    let (dx, dy) = (x - t.cx, y - t.cy);
    let (lx, ly) = (dx * cos + dy * sin, -dx * sin + dy * cos);
    Some((lx / t.scale_x + lw / 2.0, ly / t.scale_y + lh / 2.0))
}

/// Corners of a `lw` x `lh` layer on the canvas, clockwise from the top-left.
fn corners(t: &Transform, lw: f64, lh: f64) -> [(f64, f64); 4] {
    let (sin, cos) = t.rotation_deg.to_radians().sin_cos();
    let (hw, hh) = (lw / 2.0 * t.scale_x, lh / 2.0 * t.scale_y);
    [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)].map(|(x, y)| (t.cx + x * cos - y * sin, t.cy + x * sin + y * cos))
}

/// Premultiplied texel as 0..1 floats; coordinates outside the picture clamp to its edge (the
/// layer's box edge is antialiased by geometry, see `draw_layer`).
#[inline]
fn texel(r: &Raster, x: i32, y: i32) -> [f32; 4] {
    let x = x.clamp(0, r.w as i32 - 1) as usize;
    let y = y.clamp(0, r.h as i32 - 1) as usize;
    let i = (y * r.w as usize + x) * 4;
    let a = f32::from(r.px[i + 3]) / 255.0;
    [f32::from(r.px[i]) / 255.0 * a, f32::from(r.px[i + 1]) / 255.0 * a, f32::from(r.px[i + 2]) / 255.0 * a, a]
}

/// Bilinear sample (premultiplied) at raster coordinates (pixel centres sit at +0.5), clamped to the edge.
#[inline]
fn sample(r: &Raster, u: f32, v: f32) -> [f32; 4] {
    let (fx, fy) = (u - 0.5, v - 0.5);
    let (x0, y0) = (fx.floor(), fy.floor());
    let (tx, ty) = (fx - x0, fy - y0);
    let (xi, yi) = (x0 as i32, y0 as i32);
    let (p00, p10, p01, p11) = (texel(r, xi, yi), texel(r, xi + 1, yi), texel(r, xi, yi + 1), texel(r, xi + 1, yi + 1));
    let mut out = [0.0; 4];
    for c in 0..4 {
        let top = p00[c] * (1.0 - tx) + p10[c] * tx;
        let bot = p01[c] * (1.0 - tx) + p11[c] * tx;
        out[c] = top * (1.0 - ty) + bot * ty;
    }
    out
}

#[inline]
fn hard_light(cb: f32, cs: f32) -> f32 {
    if cs <= 0.5 { cb * 2.0 * cs } else { cb + (2.0 * cs - 1.0) - cb * (2.0 * cs - 1.0) }
}

/// W3C separable blend function B(cb, cs) on straight colour channels.
#[inline]
fn blend_channel(mode: BlendMode, cb: f32, cs: f32) -> f32 {
    match mode {
        BlendMode::Normal => cs,
        BlendMode::Multiply => cb * cs,
        BlendMode::Screen => cb + cs - cb * cs,
        BlendMode::Overlay => hard_light(cs, cb),
        BlendMode::Darken => cb.min(cs),
        BlendMode::Lighten => cb.max(cs),
    }
}

/// Composites premultiplied `src` (opacity already applied) over premultiplied `dst`.
#[inline]
fn blend_pixel(dst: &mut [f32], src: [f32; 4], mode: BlendMode) {
    let (as_, ab) = (src[3], dst[3]);
    if mode == BlendMode::Normal || ab <= 0.0 {
        for c in 0..4 {
            dst[c] = src[c] + dst[c] * (1.0 - as_);
        }
        return;
    }
    // General formula: Cr*ar = (1-as)*ab*Cb + (1-ab)*as*Cs + as*ab*B(Cb, Cs), all premultiplied below.
    for c in 0..3 {
        let cs = (src[c] / as_).clamp(0.0, 1.0);
        let cb = (dst[c] / ab).clamp(0.0, 1.0);
        let b = blend_channel(mode, cb, cs);
        dst[c] = (1.0 - as_) * dst[c] + (1.0 - ab) * src[c] + as_ * ab * b;
    }
    dst[3] = as_ + ab * (1.0 - as_);
}

#[cfg(test)]
mod tests {
    use super::*;
    use sevendesign_doc::{Document, Rgba, TextContent};

    struct One(Arc<Raster>);
    impl AssetSource for One {
        fn load(&self, _id: AssetId, _s: f32) -> Option<Arc<Raster>> {
            Some(self.0.clone())
        }
    }

    fn solid(w: u32, h: u32, c: [u8; 4]) -> Raster {
        Raster::from_rgba(w, h, c.iter().copied().cycle().take((w * h * 4) as usize).collect()).unwrap()
    }

    fn doc(w: u32, h: u32, bg: Background) -> Document {
        Document::new("t", w, h, 72.0, bg).unwrap()
    }

    fn image_layer(doc: &mut Document, lw: u32, lh: u32, t: Transform) -> LayerId {
        doc.push_layer(Layer { kind: LayerKind::Image { asset: 1, width: lw, height: lh }, transform: t, ..Default::default() })
    }

    fn px(r: &Raster, x: u32, y: u32) -> [u8; 4] {
        let i = ((y * r.w + x) * 4) as usize;
        [r.px[i], r.px[i + 1], r.px[i + 2], r.px[i + 3]]
    }

    fn full(w: u32, h: u32) -> IRect {
        IRect { x: 0, y: 0, w, h }
    }

    #[test]
    fn background_only() {
        let d = doc(4, 4, Background::Solid(Rgba([10, 20, 30, 255])));
        let r = Renderer::new().render_region(&d, &One(Arc::new(solid(1, 1, [0; 4]))), full(4, 4), 1.0);
        assert_eq!(px(&r, 2, 2), [10, 20, 30, 255]);
        let t = doc(4, 4, Background::Transparent);
        let r = Renderer::new().render_region(&t, &One(Arc::new(solid(1, 1, [0; 4]))), full(4, 4), 1.0);
        assert_eq!(px(&r, 2, 2), [0, 0, 0, 0]);
    }

    #[test]
    fn scaled_image_covers_its_box_only() {
        let mut d = doc(100, 100, Background::Transparent);
        image_layer(&mut d, 2, 2, Transform { cx: 50.0, cy: 50.0, scale_x: 25.0, scale_y: 25.0, rotation_deg: 0.0 });
        let r = Renderer::new().render_region(&d, &One(Arc::new(solid(2, 2, [255, 0, 0, 255]))), full(100, 100), 1.0);
        assert_eq!(px(&r, 50, 50), [255, 0, 0, 255]);
        assert_eq!(px(&r, 30, 30), [255, 0, 0, 255]);
        assert_eq!(px(&r, 10, 10)[3], 0);
        assert_eq!(px(&r, 90, 90)[3], 0);
    }

    #[test]
    fn rotation_by_90_swaps_the_box() {
        // a 40x10 bar centred at (50,50), turned 90 degrees, covers x 45..55, y 30..70
        let mut d = doc(100, 100, Background::Transparent);
        image_layer(&mut d, 40, 10, Transform { cx: 50.0, cy: 50.0, scale_x: 1.0, scale_y: 1.0, rotation_deg: 90.0 });
        let r = Renderer::new().render_region(&d, &One(Arc::new(solid(40, 10, [0, 0, 255, 255]))), full(100, 100), 1.0);
        assert_eq!(px(&r, 50, 35)[3], 255);
        assert_eq!(px(&r, 50, 65)[3], 255);
        assert_eq!(px(&r, 30, 50)[3], 0);
        assert_eq!(px(&r, 70, 50)[3], 0);
    }

    #[test]
    fn opacity_mixes_with_the_background() {
        let mut d = doc(10, 10, Background::Solid(Rgba([0, 0, 0, 255])));
        let id = image_layer(&mut d, 1, 1, Transform { cx: 5.0, cy: 5.0, scale_x: 10.0, scale_y: 10.0, rotation_deg: 0.0 });
        d.layer_mut(id).unwrap().opacity = 0.5;
        let r = Renderer::new().render_region(&d, &One(Arc::new(solid(1, 1, [255, 255, 255, 255]))), full(10, 10), 1.0);
        let p = px(&r, 5, 5);
        assert!((i32::from(p[0]) - 128).abs() <= 1 && p[3] == 255, "{p:?}");
    }

    #[test]
    fn multiply_darkens() {
        let mut d = doc(10, 10, Background::Solid(Rgba([128, 128, 128, 255])));
        let id = image_layer(&mut d, 1, 1, Transform { cx: 5.0, cy: 5.0, scale_x: 10.0, scale_y: 10.0, rotation_deg: 0.0 });
        d.layer_mut(id).unwrap().blend = BlendMode::Multiply;
        let r = Renderer::new().render_region(&d, &One(Arc::new(solid(1, 1, [255, 0, 0, 255]))), full(10, 10), 1.0);
        let p = px(&r, 5, 5);
        assert!((i32::from(p[0]) - 128).abs() <= 1 && p[1] == 0 && p[2] == 0, "{p:?}");
    }

    #[test]
    fn hidden_layers_are_not_drawn() {
        let mut d = doc(10, 10, Background::Transparent);
        let id = image_layer(&mut d, 1, 1, Transform { cx: 5.0, cy: 5.0, scale_x: 10.0, scale_y: 10.0, rotation_deg: 0.0 });
        d.layer_mut(id).unwrap().visible = false;
        let r = Renderer::new().render_region(&d, &One(Arc::new(solid(1, 1, [255, 0, 0, 255]))), full(10, 10), 1.0);
        assert_eq!(px(&r, 5, 5)[3], 0);
    }

    #[test]
    fn a_region_equals_the_same_part_of_the_full_render() {
        let mut d = doc(60, 40, Background::Solid(Rgba([9, 9, 9, 255])));
        image_layer(&mut d, 2, 2, Transform { cx: 30.0, cy: 20.0, scale_x: 12.0, scale_y: 7.0, rotation_deg: 30.0 });
        let src = One(Arc::new(solid(2, 2, [200, 100, 50, 255])));
        let rd = Renderer::new();
        let whole = rd.render_region(&d, &src, full(60, 40), 1.0);
        let part = rd.render_region(&d, &src, IRect { x: 20, y: 10, w: 25, h: 15 }, 1.0);
        for y in 0..15 {
            for x in 0..25 {
                assert_eq!(px(&part, x, y), px(&whole, x + 20, y + 10));
            }
        }
    }

    #[test]
    fn tiled_export_has_no_seams() {
        let mut d = doc(700, 600, Background::Solid(Rgba([1, 2, 3, 255])));
        image_layer(&mut d, 2, 2, Transform { cx: 350.0, cy: 300.0, scale_x: 200.0, scale_y: 150.0, rotation_deg: 17.0 });
        d.push_layer(Layer { kind: LayerKind::Text(TextContent { text: "Hola".into(), size_px: 120.0, ..Default::default() }), transform: Transform { cx: 350.0, cy: 300.0, ..Default::default() }, ..Default::default() });
        let src = One(Arc::new(solid(2, 2, [200, 100, 50, 255])));
        let rd = Renderer::new();
        let tiled = rd.render_full(&d, &src, 1.0).unwrap();
        let single = rd.render_region(&d, &src, full(700, 600), 1.0);
        assert!(tiled == single);
    }

    #[test]
    fn export_scale_doubles_the_size_and_rejects_huge_outputs() {
        let d = doc(30, 20, Background::Transparent);
        let src = One(Arc::new(solid(1, 1, [0; 4])));
        let r = Renderer::new().render_full(&d, &src, 2.0).unwrap();
        assert_eq!((r.w, r.h), (60, 40));
        let big = doc(16_000, 3_000, Background::Transparent);
        assert!(matches!(Renderer::new().render_full(&big, &src, 4.0), Err(RenderError::TooLarge(..))));
    }

    #[test]
    fn hit_test_finds_the_topmost_layer_under_the_point() {
        let mut d = doc(100, 100, Background::Transparent);
        let t = Transform { cx: 50.0, cy: 50.0, scale_x: 1.0, scale_y: 1.0, rotation_deg: 0.0 };
        let below = image_layer(&mut d, 40, 40, t);
        let above = image_layer(&mut d, 20, 20, t);
        let rd = Renderer::new();
        assert_eq!(rd.hit_test(&d, 50.0, 50.0), Some(above));
        assert_eq!(rd.hit_test(&d, 35.0, 35.0), Some(below));
        assert_eq!(rd.hit_test(&d, 5.0, 5.0), None);
        d.layer_mut(above).unwrap().visible = false;
        assert_eq!(rd.hit_test(&d, 50.0, 50.0), Some(below));
    }

    #[test]
    fn missing_asset_skips_the_layer() {
        struct None_;
        impl AssetSource for None_ {
            fn load(&self, _: AssetId, _: f32) -> Option<Arc<Raster>> {
                None
            }
        }
        let mut d = doc(10, 10, Background::Transparent);
        image_layer(&mut d, 1, 1, Transform { cx: 5.0, cy: 5.0, scale_x: 10.0, scale_y: 10.0, rotation_deg: 0.0 });
        let r = Renderer::new().render_region(&d, &None_, full(10, 10), 1.0);
        assert_eq!(px(&r, 5, 5)[3], 0);
    }
}
