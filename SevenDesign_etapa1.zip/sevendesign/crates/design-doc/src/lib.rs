//! Seven Design document model.
//!
//! The document holds only *metadata*: canvas size, layer list, transforms, text content and
//! references to assets (image files that live outside the document). Pixels never sit in the
//! document, so an undo step is a cheap clone of a few kilobytes even with many large photos.
//!
//! - [`model`]: [`Document`], [`Layer`], [`LayerKind`], [`AssetMeta`] and the JSON format.
//! - [`history`]: [`Editor`], the document with its undo/redo stack and the edit operations.

pub mod history;
pub mod model;

pub use history::Editor;
pub use model::{
    AssetId, AssetMeta, Background, BlendMode, DocError, Document, FORMAT_VERSION, Layer, LayerId, LayerKind, Rgba, TextAlign, TextContent, Transform,
};
