use serde::{Deserialize, Serialize};

/// Version of the JSON document format written by this build. A file with a higher version is
/// refused (not guessed at); lower versions are migrated in [`Document::from_json`].
pub const FORMAT_VERSION: u32 = 1;

pub type LayerId = u64;
pub type AssetId = u64;

/// Canvas side limits. The pixel cap bounds the export buffer (RGBA8: 4 bytes per pixel).
pub const MAX_SIDE: u32 = 16_384;
pub const MAX_PIXELS: u64 = 50_000_000;

#[derive(Debug, thiserror::Error, PartialEq)]
pub enum DocError {
    #[error("canvas size {0}x{1} is not valid (1 to 16384 per side, at most 50000000 pixels)")]
    BadSize(u32, u32),
    #[error("layer {0} not found")]
    NoLayer(LayerId),
    #[error("layer {0} is locked")]
    Locked(LayerId),
    #[error("index {0} is out of range")]
    BadIndex(usize),
    #[error("document format version {0} is newer than this app supports")]
    TooNew(u32),
    #[error("document could not be read: {0}")]
    Parse(String),
}

/// Straight (non-premultiplied) sRGB colour, 8 bits per channel.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Rgba(pub [u8; 4]);

impl Rgba {
    pub const WHITE: Rgba = Rgba([255, 255, 255, 255]);
    pub const BLACK: Rgba = Rgba([0, 0, 0, 255]);
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(tag = "kind", content = "color")]
pub enum Background {
    Transparent,
    Solid(Rgba),
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum BlendMode {
    #[default]
    Normal,
    Multiply,
    Screen,
    Overlay,
    Darken,
    Lighten,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub enum TextAlign {
    #[default]
    Left,
    Center,
    Right,
}

/// Placement of a layer on the canvas. `cx`,`cy` is where the layer's centre sits in canvas
/// pixels; the layer is scaled about its centre, then rotated clockwise by `rotation_deg`.
#[derive(Clone, Copy, Debug, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct Transform {
    pub cx: f64,
    pub cy: f64,
    pub scale_x: f64,
    pub scale_y: f64,
    pub rotation_deg: f64,
}

impl Default for Transform {
    fn default() -> Self {
        Self { cx: 0.0, cy: 0.0, scale_x: 1.0, scale_y: 1.0, rotation_deg: 0.0 }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct TextContent {
    pub text: String,
    pub family: String,
    pub style: String,
    /// Font size in canvas pixels.
    pub size_px: f32,
    pub color: Rgba,
    pub align: TextAlign,
    /// Tracking in 1/1000 em.
    pub tracking: f32,
    /// Extra line spacing in pixels.
    pub leading: f32,
    /// Wrap width in pixels; `None` = point text (no wrapping).
    pub box_width: Option<f32>,
}

impl Default for TextContent {
    fn default() -> Self {
        Self {
            text: String::new(),
            family: "Inter".into(),
            style: "Regular".into(),
            size_px: 96.0,
            color: Rgba::BLACK,
            align: TextAlign::Left,
            tracking: 0.0,
            leading: 0.0,
            box_width: None,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum LayerKind {
    /// A picture. `width`/`height` are the asset's pixel size (the layer's natural size).
    Image { asset: AssetId, width: u32, height: u32 },
    Text(TextContent),
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct Layer {
    pub id: LayerId,
    pub name: String,
    pub visible: bool,
    pub locked: bool,
    /// 0.0..=1.0
    pub opacity: f32,
    pub blend: BlendMode,
    pub transform: Transform,
    pub kind: LayerKind,
}

impl Default for Layer {
    fn default() -> Self {
        Self {
            id: 0,
            name: String::new(),
            visible: true,
            locked: false,
            opacity: 1.0,
            blend: BlendMode::Normal,
            transform: Transform::default(),
            kind: LayerKind::Text(TextContent::default()),
        }
    }
}

/// An image file the document refers to. `file` is relative to the project folder.
#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct AssetMeta {
    pub id: AssetId,
    pub name: String,
    pub file: String,
    pub width: u32,
    pub height: u32,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct Document {
    pub version: u32,
    pub name: String,
    pub width: u32,
    pub height: u32,
    pub dpi: f32,
    pub background: Background,
    /// Bottom to top: the last layer is drawn last (on top).
    pub layers: Vec<Layer>,
    pub assets: Vec<AssetMeta>,
    pub next_id: u64,
}

impl Default for Document {
    fn default() -> Self {
        Self {
            version: FORMAT_VERSION,
            name: String::new(),
            width: 1080,
            height: 1080,
            dpi: 72.0,
            background: Background::Solid(Rgba::WHITE),
            layers: Vec::new(),
            assets: Vec::new(),
            next_id: 1,
        }
    }
}

pub fn check_size(width: u32, height: u32) -> Result<(), DocError> {
    let ok = (1..=MAX_SIDE).contains(&width) && (1..=MAX_SIDE).contains(&height) && u64::from(width) * u64::from(height) <= MAX_PIXELS;
    if ok { Ok(()) } else { Err(DocError::BadSize(width, height)) }
}

impl Document {
    pub fn new(name: &str, width: u32, height: u32, dpi: f32, background: Background) -> Result<Self, DocError> {
        check_size(width, height)?;
        Ok(Self { name: name.to_string(), width, height, dpi: if dpi.is_finite() && dpi > 0.0 { dpi } else { 72.0 }, background, ..Self::default() })
    }

    /// A fresh id for a layer or an asset (one counter, never reused within a document).
    pub fn alloc_id(&mut self) -> u64 {
        let id = self.next_id;
        self.next_id += 1;
        id
    }

    pub fn index_of(&self, id: LayerId) -> Option<usize> {
        self.layers.iter().position(|l| l.id == id)
    }

    pub fn layer(&self, id: LayerId) -> Option<&Layer> {
        self.layers.iter().find(|l| l.id == id)
    }

    pub fn layer_mut(&mut self, id: LayerId) -> Option<&mut Layer> {
        self.layers.iter_mut().find(|l| l.id == id)
    }

    pub fn asset(&self, id: AssetId) -> Option<&AssetMeta> {
        self.assets.iter().find(|a| a.id == id)
    }

    /// Adds a layer on top and gives it a fresh id. Returns the id.
    pub fn push_layer(&mut self, mut layer: Layer) -> LayerId {
        layer.id = self.alloc_id();
        let id = layer.id;
        self.layers.push(layer);
        id
    }

    pub fn to_json(&self) -> Result<String, DocError> {
        serde_json::to_string_pretty(self).map_err(|e| DocError::Parse(e.to_string()))
    }

    /// Reads a document, refusing a newer format. Fields missing from older files take their
    /// defaults (`#[serde(default)]`), so adding a field never breaks old documents.
    pub fn from_json(json: &str) -> Result<Self, DocError> {
        let mut doc: Document = serde_json::from_str(json).map_err(|e| DocError::Parse(e.to_string()))?;
        if doc.version > FORMAT_VERSION {
            return Err(DocError::TooNew(doc.version));
        }
        // Defensive repairs: a hand-edited or damaged file must not crash the editor.
        check_size(doc.width, doc.height)?;
        doc.version = FORMAT_VERSION;
        let max_used = doc.layers.iter().map(|l| l.id).chain(doc.assets.iter().map(|a| a.id)).max().unwrap_or(0);
        doc.next_id = doc.next_id.max(max_used + 1);
        for l in &mut doc.layers {
            l.opacity = if l.opacity.is_finite() { l.opacity.clamp(0.0, 1.0) } else { 1.0 };
        }
        Ok(doc)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn size_limits() {
        assert!(Document::new("a", 1080, 1080, 72.0, Background::Transparent).is_ok());
        assert_eq!(Document::new("a", 0, 10, 72.0, Background::Transparent), Err(DocError::BadSize(0, 10)));
        assert!(Document::new("a", 16_385, 10, 72.0, Background::Transparent).is_err());
        assert!(Document::new("a", 10_000, 10_000, 72.0, Background::Transparent).is_err());
    }

    #[test]
    fn json_round_trip() {
        let mut d = Document::new("poster", 800, 600, 300.0, Background::Solid(Rgba([10, 20, 30, 255]))).unwrap();
        let id = d.push_layer(Layer { name: "T".into(), kind: LayerKind::Text(TextContent { text: "Hola".into(), ..Default::default() }), ..Default::default() });
        d.assets.push(AssetMeta { id: d.alloc_id(), name: "foto".into(), file: "assets/2.png".into(), width: 4, height: 4 });
        let back = Document::from_json(&d.to_json().unwrap()).unwrap();
        assert_eq!(back, d);
        assert!(back.layer(id).is_some());
    }

    #[test]
    fn newer_version_is_refused() {
        let mut d = Document::default();
        d.version = FORMAT_VERSION + 1;
        let json = serde_json::to_string(&d).unwrap();
        assert_eq!(Document::from_json(&json), Err(DocError::TooNew(FORMAT_VERSION + 1)));
    }

    #[test]
    fn missing_fields_take_defaults_and_ids_stay_unique() {
        let json = r#"{"version":1,"width":100,"height":50,"layers":[{"id":7,"kind":{"type":"Text","text":"x"}}]}"#;
        let d = Document::from_json(json).unwrap();
        assert_eq!(d.layers[0].opacity, 1.0);
        assert!(d.next_id > 7);
    }

    #[test]
    fn garbage_is_an_error_not_a_panic() {
        assert!(matches!(Document::from_json("{not json"), Err(DocError::Parse(_))));
    }
}
