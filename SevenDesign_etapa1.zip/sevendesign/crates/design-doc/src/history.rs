//! The document with its undo/redo history and the edit operations the app calls.
//!
//! Every edit goes through [`Editor::apply`] (one undo step) or [`Editor::apply_coalesced`]
//! (a continuous gesture such as a drag: all calls with the same key share one step). Undo
//! restores a snapshot of the document. That is cheap because a [`Document`] holds no pixels.
//! When pixel editing arrives (brushes), it adds per-layer pixel deltas next to these snapshots.

use crate::model::{
    AssetId, AssetMeta, BlendMode, DocError, Document, Layer, LayerId, LayerKind, TextContent, Transform,
};

/// Most undo steps kept; the oldest is dropped beyond it.
pub const MAX_UNDO: usize = 100;

#[derive(Clone, Debug)]
pub struct Editor {
    doc: Document,
    undo: Vec<(String, Document)>,
    redo: Vec<(String, Document)>,
    /// Key of the open gesture, if the last edit was a coalesced one.
    open_key: Option<String>,
    /// Edits since the last [`Editor::mark_saved`].
    dirty: bool,
}

impl Editor {
    pub fn new(doc: Document) -> Self {
        Self { doc, undo: Vec::new(), redo: Vec::new(), open_key: None, dirty: false }
    }

    pub fn doc(&self) -> &Document {
        &self.doc
    }

    pub fn is_dirty(&self) -> bool {
        self.dirty
    }

    pub fn mark_saved(&mut self) {
        self.dirty = false;
    }

    pub fn can_undo(&self) -> bool {
        !self.undo.is_empty()
    }

    pub fn can_redo(&self) -> bool {
        !self.redo.is_empty()
    }

    /// Label of the step undo would revert.
    pub fn undo_label(&self) -> Option<&str> {
        self.undo.last().map(|(l, _)| l.as_str())
    }

    fn snapshot(&mut self, label: &str) {
        self.undo.push((label.to_string(), self.doc.clone()));
        if self.undo.len() > MAX_UNDO {
            self.undo.remove(0);
        }
        self.redo.clear();
    }

    /// Runs one edit as one undo step. Ends any open gesture.
    pub fn apply<R>(&mut self, label: &str, f: impl FnOnce(&mut Document) -> R) -> R {
        self.open_key = None;
        self.snapshot(label);
        self.dirty = true;
        f(&mut self.doc)
    }

    /// Like [`Editor::apply`], but consecutive calls with the same `key` make a single step.
    pub fn apply_coalesced<R>(&mut self, key: &str, label: &str, f: impl FnOnce(&mut Document) -> R) -> R {
        if self.open_key.as_deref() != Some(key) {
            self.snapshot(label);
            self.open_key = Some(key.to_string());
        }
        self.dirty = true;
        f(&mut self.doc)
    }

    /// Closes the open gesture: the next coalesced edit starts a new step.
    pub fn end_gesture(&mut self) {
        self.open_key = None;
    }

    pub fn undo(&mut self) -> bool {
        self.open_key = None;
        let Some((label, prev)) = self.undo.pop() else { return false };
        let current = std::mem::replace(&mut self.doc, prev);
        self.redo.push((label, current));
        self.dirty = true;
        true
    }

    pub fn redo(&mut self) -> bool {
        self.open_key = None;
        let Some((label, next)) = self.redo.pop() else { return false };
        let current = std::mem::replace(&mut self.doc, next);
        self.undo.push((label, current));
        self.dirty = true;
        true
    }

    // ---- edit operations -------------------------------------------------------------------

    /// Registers an image file (already stored in the project) and returns its id.
    pub fn add_asset(&mut self, name: &str, file: &str, width: u32, height: u32) -> AssetId {
        self.apply("Import image", |d| {
            let id = d.alloc_id();
            d.assets.push(AssetMeta { id, name: name.to_string(), file: file.to_string(), width, height });
            id
        })
    }

    /// Adds a picture layer for `asset`, centred on the canvas and shrunk to fit it if larger.
    pub fn add_image_layer(&mut self, name: &str, asset: AssetId) -> Result<LayerId, DocError> {
        let meta = self.doc.asset(asset).cloned().ok_or(DocError::NoLayer(asset))?;
        Ok(self.apply("Add image", |d| {
            let fit = (f64::from(d.width) / f64::from(meta.width)).min(f64::from(d.height) / f64::from(meta.height)).min(1.0);
            d.push_layer(Layer {
                name: name.to_string(),
                kind: LayerKind::Image { asset, width: meta.width, height: meta.height },
                transform: Transform { cx: f64::from(d.width) / 2.0, cy: f64::from(d.height) / 2.0, scale_x: fit, scale_y: fit, rotation_deg: 0.0 },
                ..Default::default()
            })
        }))
    }

    /// Registers an image file and adds a layer for it as ONE undo step: the file must already
    /// be stored in the project under the name `assets/<next_id>.<ext>` (the caller reads
    /// `doc().next_id` first). The layer is centred and shrunk to fit the canvas if larger.
    pub fn import_image(&mut self, name: &str, file: &str, width: u32, height: u32) -> (AssetId, LayerId) {
        self.apply("Import image", |d| {
            let asset = d.alloc_id();
            d.assets.push(AssetMeta { id: asset, name: name.to_string(), file: file.to_string(), width, height });
            let fit = (f64::from(d.width) / f64::from(width.max(1))).min(f64::from(d.height) / f64::from(height.max(1))).min(1.0);
            let layer = d.push_layer(Layer {
                name: name.to_string(),
                kind: LayerKind::Image { asset, width, height },
                transform: Transform { cx: f64::from(d.width) / 2.0, cy: f64::from(d.height) / 2.0, scale_x: fit, scale_y: fit, rotation_deg: 0.0 },
                ..Default::default()
            });
            (asset, layer)
        })
    }

    /// Adds a text layer; its centre is the canvas centre until moved.
    pub fn add_text_layer(&mut self, content: TextContent) -> LayerId {
        self.apply("Add text", |d| {
            let name: String = content.text.chars().take(24).collect();
            d.push_layer(Layer {
                name: if name.trim().is_empty() { "Text".to_string() } else { name },
                kind: LayerKind::Text(content),
                transform: Transform { cx: f64::from(d.width) / 2.0, cy: f64::from(d.height) / 2.0, ..Default::default() },
                ..Default::default()
            })
        })
    }

    fn editable(&mut self, id: LayerId) -> Result<(), DocError> {
        match self.doc.layer(id) {
            None => Err(DocError::NoLayer(id)),
            Some(l) if l.locked => Err(DocError::Locked(id)),
            Some(_) => Ok(()),
        }
    }

    /// Moves/rotates/scales a layer. Coalesced per layer: a whole drag is one undo step.
    pub fn set_transform(&mut self, id: LayerId, t: Transform) -> Result<(), DocError> {
        self.editable(id)?;
        self.apply_coalesced(&format!("transform:{id}"), "Transform", |d| {
            if let Some(l) = d.layer_mut(id) {
                l.transform = t;
            }
        });
        Ok(())
    }

    /// Replaces the text of a text layer (coalesced per layer while typing).
    pub fn set_text(&mut self, id: LayerId, content: TextContent) -> Result<(), DocError> {
        self.editable(id)?;
        if !matches!(self.doc.layer(id).map(|l| &l.kind), Some(LayerKind::Text(_))) {
            return Err(DocError::NoLayer(id));
        }
        self.apply_coalesced(&format!("text:{id}"), "Edit text", |d| {
            if let Some(l) = d.layer_mut(id) {
                l.kind = LayerKind::Text(content);
            }
        });
        Ok(())
    }

    pub fn set_opacity(&mut self, id: LayerId, opacity: f32) -> Result<(), DocError> {
        self.editable(id)?;
        let o = if opacity.is_finite() { opacity.clamp(0.0, 1.0) } else { 1.0 };
        self.apply_coalesced(&format!("opacity:{id}"), "Opacity", |d| {
            if let Some(l) = d.layer_mut(id) {
                l.opacity = o;
            }
        });
        Ok(())
    }

    pub fn set_blend(&mut self, id: LayerId, blend: BlendMode) -> Result<(), DocError> {
        self.editable(id)?;
        self.apply("Blend mode", |d| {
            if let Some(l) = d.layer_mut(id) {
                l.blend = blend;
            }
        });
        Ok(())
    }

    pub fn set_visible(&mut self, id: LayerId, visible: bool) -> Result<(), DocError> {
        if self.doc.layer(id).is_none() {
            return Err(DocError::NoLayer(id));
        }
        self.apply(if visible { "Show layer" } else { "Hide layer" }, |d| {
            if let Some(l) = d.layer_mut(id) {
                l.visible = visible;
            }
        });
        Ok(())
    }

    pub fn set_locked(&mut self, id: LayerId, locked: bool) -> Result<(), DocError> {
        if self.doc.layer(id).is_none() {
            return Err(DocError::NoLayer(id));
        }
        self.apply(if locked { "Lock layer" } else { "Unlock layer" }, |d| {
            if let Some(l) = d.layer_mut(id) {
                l.locked = locked;
            }
        });
        Ok(())
    }

    pub fn rename(&mut self, id: LayerId, name: &str) -> Result<(), DocError> {
        if self.doc.layer(id).is_none() {
            return Err(DocError::NoLayer(id));
        }
        self.apply("Rename layer", |d| {
            if let Some(l) = d.layer_mut(id) {
                l.name = name.to_string();
            }
        });
        Ok(())
    }

    pub fn delete_layer(&mut self, id: LayerId) -> Result<(), DocError> {
        self.editable(id)?;
        self.apply("Delete layer", |d| d.layers.retain(|l| l.id != id));
        Ok(())
    }

    /// Duplicates a layer just above the original, offset by 24 px. Returns the new id.
    pub fn duplicate_layer(&mut self, id: LayerId) -> Result<LayerId, DocError> {
        let src = self.doc.layer(id).cloned().ok_or(DocError::NoLayer(id))?;
        Ok(self.apply("Duplicate layer", |d| {
            let at = d.index_of(id).map_or(d.layers.len(), |i| i + 1);
            let mut copy = src;
            copy.id = d.alloc_id();
            copy.name = format!("{} copy", copy.name);
            copy.locked = false;
            copy.transform.cx += 24.0;
            copy.transform.cy += 24.0;
            let new_id = copy.id;
            d.layers.insert(at, copy);
            new_id
        }))
    }

    /// Moves a layer to `index` in the bottom-to-top list (0 = bottom).
    pub fn move_layer(&mut self, id: LayerId, index: usize) -> Result<(), DocError> {
        let from = self.doc.index_of(id).ok_or(DocError::NoLayer(id))?;
        if index >= self.doc.layers.len() {
            return Err(DocError::BadIndex(index));
        }
        if from != index {
            self.apply("Reorder layer", |d| {
                let l = d.layers.remove(from);
                d.layers.insert(index, l);
            });
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::Background;

    fn editor() -> Editor {
        Editor::new(Document::new("t", 1000, 800, 72.0, Background::Transparent).unwrap())
    }

    fn text(s: &str) -> TextContent {
        TextContent { text: s.into(), ..Default::default() }
    }

    #[test]
    fn undo_redo_round_trip() {
        let mut e = editor();
        let a = e.add_text_layer(text("A"));
        e.add_text_layer(text("B"));
        assert_eq!(e.doc().layers.len(), 2);
        assert!(e.undo());
        assert_eq!(e.doc().layers.len(), 1);
        assert!(e.redo());
        assert_eq!(e.doc().layers.len(), 2);
        assert!(e.doc().layer(a).is_some());
        assert!(!e.redo());
    }

    #[test]
    fn new_edit_clears_redo() {
        let mut e = editor();
        e.add_text_layer(text("A"));
        e.undo();
        assert!(e.can_redo());
        e.add_text_layer(text("B"));
        assert!(!e.can_redo());
    }

    #[test]
    fn a_drag_is_one_undo_step() {
        let mut e = editor();
        let id = e.add_text_layer(text("A"));
        let start = e.doc().layer(id).unwrap().transform;
        for i in 1..=20 {
            e.set_transform(id, Transform { cx: start.cx + f64::from(i), ..start }).unwrap();
        }
        e.end_gesture();
        assert_eq!(e.doc().layer(id).unwrap().transform.cx, start.cx + 20.0);
        e.undo();
        assert_eq!(e.doc().layer(id).unwrap().transform, start);
    }

    #[test]
    fn two_drags_are_two_steps() {
        let mut e = editor();
        let id = e.add_text_layer(text("A"));
        let t0 = e.doc().layer(id).unwrap().transform;
        e.set_transform(id, Transform { cx: 1.0, ..t0 }).unwrap();
        e.end_gesture();
        e.set_transform(id, Transform { cx: 2.0, ..t0 }).unwrap();
        e.end_gesture();
        e.undo();
        assert_eq!(e.doc().layer(id).unwrap().transform.cx, 1.0);
        e.undo();
        assert_eq!(e.doc().layer(id).unwrap().transform, t0);
    }

    #[test]
    fn locked_layer_refuses_edits() {
        let mut e = editor();
        let id = e.add_text_layer(text("A"));
        e.set_locked(id, true).unwrap();
        assert_eq!(e.set_opacity(id, 0.5), Err(DocError::Locked(id)));
        assert_eq!(e.delete_layer(id), Err(DocError::Locked(id)));
        assert_eq!(e.doc().layer(id).unwrap().opacity, 1.0);
    }

    #[test]
    fn duplicate_and_reorder() {
        let mut e = editor();
        let a = e.add_text_layer(text("A"));
        let b = e.add_text_layer(text("B"));
        let a2 = e.duplicate_layer(a).unwrap();
        let ids: Vec<_> = e.doc().layers.iter().map(|l| l.id).collect();
        assert_eq!(ids, vec![a, a2, b]);
        e.move_layer(b, 0).unwrap();
        let ids: Vec<_> = e.doc().layers.iter().map(|l| l.id).collect();
        assert_eq!(ids, vec![b, a, a2]);
        assert_eq!(e.move_layer(b, 9), Err(DocError::BadIndex(9)));
    }

    #[test]
    fn image_layer_is_fitted_to_canvas() {
        let mut e = editor();
        let asset = e.add_asset("big", "assets/1.png", 4000, 2000);
        let id = e.add_image_layer("big", asset).unwrap();
        let t = e.doc().layer(id).unwrap().transform;
        assert_eq!(t.scale_x, 0.25); // 1000 / 4000
        assert_eq!((t.cx, t.cy), (500.0, 400.0));
    }

    #[test]
    fn import_is_a_single_undo_step() {
        let mut e = editor();
        let expected = e.doc().next_id;
        let (asset, layer) = e.import_image("foto", &format!("assets/{expected}.png"), 500, 400);
        assert_eq!(asset, expected);
        assert!(e.doc().layer(layer).is_some() && e.doc().asset(asset).is_some());
        assert!(e.undo());
        assert!(e.doc().layers.is_empty() && e.doc().assets.is_empty());
        assert!(!e.undo());
    }

    #[test]
    fn history_is_bounded() {
        let mut e = editor();
        for _ in 0..(MAX_UNDO + 20) {
            e.add_text_layer(text("x"));
        }
        let mut n = 0;
        while e.undo() {
            n += 1;
        }
        assert_eq!(n, MAX_UNDO);
    }

    #[test]
    fn dirty_flag() {
        let mut e = editor();
        assert!(!e.is_dirty());
        e.add_text_layer(text("A"));
        assert!(e.is_dirty());
        e.mark_saved();
        assert!(!e.is_dirty());
    }
}
