# Estado verificable (etapa 1)

| Elemento | Estado |
|---|---|
| Código Rust (doc, render, io, puente UniFFI) | Escrito y revisado a mano. **No compilado.** |
| Pruebas Rust (≈55) | Escritas. **No ejecutadas.** |
| App Kotlin/Compose | Escrita y revisada a mano. **No compilada.** |
| APK | **No existe.** No se afirma que funcione. |

Motivo: el entorno donde se escribió no tiene Rust (cargo), Gradle, JDK ni Android SDK, y no tiene red.

## Cómo comprobar (en este orden)
1. `cargo test -p sevendesign-doc -p sevendesign-render -p sevendesign-io -p sevendesign-android` (o el workflow *Pruebas Rust*).
2. Workflow *Compilar Seven Design para Android* → artefacto `SevenDesign-apk` (arm64-v8a, **sin firmar**: hay que firmarlo para instalarlo, igual que el flujo de Seven Cut Pro).
3. Probar en un teléfono: crear documento, importar foto, mover/rotar/escalar, texto, fuente TTF, guardar, cerrar y abrir, exportar PNG/JPG.

Es probable que la primera compilación dé errores pequeños (nombres de API, tipos sin signo de UniFFI en Kotlin, versiones). Envía el log y se corrigen.

## Límites conocidos
- Foto de cámara: la rotación EXIF se aplica en Kotlin (re-codifica a PNG si hay rotación).
- Sin pellizco/rotación con dos dedos sobre una capa **bloqueada**: en ese caso el gesto mueve el lienzo.
- La escala mínima de vista previa usa interpolación bilineal con mip por potencias de 2.
- Sin protección contra eliminar archivos de assets sin uso al guardar (no se limpian).
