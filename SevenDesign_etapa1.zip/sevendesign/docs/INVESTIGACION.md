# Investigación técnica de Seven Cut Pro r27 (sección 8)

Leyenda: **[L]** comprobado leyendo el código/configuración. **[C]** conclusión mía a partir de [L]. **[P]** pendiente: requiere compilar o ejecutar (no se pudo: este entorno no tiene Rust, Gradle ni Android SDK).

## 1. ¿Se puede usar render sin Sequence y Tick?
- **[L]** `crates/render` depende de `filmcraft-time`, `-project`, `-media`, `-audio-dsp`, `-captions`, `-text` (render/Cargo.toml). Su descripción es "Sequence evaluation and CPU reference compositor".
- **[L]** `render/src/image.rs` (tipo `Image`, f32 premultiplicado lineal) y `graphics.rs` no importan `project` ni `time`. `blend.rs` solo lo menciona en comentarios. `mask.rs`, `effects.rs` y `gpufx.rs` sí usan `filmcraft_project` y `filmcraft_time`.
- **[L]** `lib.rs` evalúa un `Sequence` en un `Tick` (funciones `item_layer_ex`, `adjustment_region`…).
- **[C]** El compositor completo **no** se puede usar sin Sequence/Tick. Reutilizarlo obligaría a arrastrar `project`, `media` (que arrastra `dng`), `audio-dsp` y `captions`. Solo `image.rs`, `blend.rs` y las fórmulas son reutilizables.
- **Decisión:** Seven Design tiene su propio compositor (`design-render`). Los 27 modos de fusión de `blend.rs` quedan como siguiente reutilización (etapa 2); en la etapa 1 hay 6 modos W3C propios.

## 2. Codificadores PNG y JPEG
- **[L]** Se usa el crate `image` 0.25.10 (Cargo.lock) con `PngEncoder` y `JpegEncoder::new_with_quality` (`export/src/still_encode.rs`). `png` 0.18.1, `zune-jpeg` 0.5.15 y `fdeflate`/`miniz_oxide` aparecen en el lock.
- **[L]** `crates/export` además trae un `deflate.rs` propio, TIFF, BMP, EXR, DPX…; no hace falta para diseño.
- **[C]** Seven Design usa `image` con `default-features = false, features = ["png","jpeg"]`: nada de video ni otros formatos. Dependencias de licencia MIT/Apache-2.0 según sus metadatos habituales; **[P]** confirmar con `cargo deny`/`cargo license` al compilar (no hay `deny.toml` en el repositorio).

## 3. Memoria, búferes, cachés, tiles
- **[L]** `Image` = `Vec<f32>` RGBA, **16 bytes por píxel**; `MAX_PIXELS = 268 435 456` (= más de 4 GB). Una capa de 4000×4000 ocupa 256 MB.
- **[L]** `frame` tiene un pool de búferes (`take_f32_overwritten`, `recycle_f32`, `trim_f32`) y `Region`; en `render/lib.rs` existe `Layer::Region` (caja delimitadora de una capa de medios simple).
- **[L]** No hay tiles ni regiones sucias por edición; `Region` solo recorta el área opaca de un fotograma.
- **[C]** Para documentos de varias capas grandes el modelo f32 lineal completo no sirve en un teléfono. Seven Design guarda las imágenes en disco, las decodifica a pedido y compone **por regiones** (visible en pantalla / teselas de 512 px en la exportación) con caché LRU de niveles mip.

## 4. Dependencias reales de texto y gráficos
- **[L]** `crates/text` depende solo de `filmcraft-color`, `skrifa`, `harfrust`, `unicode-bidi`, `unicode-linebreak`, `unicode-segmentation`. No usa tiempo, proyecto, video ni audio. Fuentes incluidas con `include_bytes!` desde `assets/fonts` (Inter, JetBrains Mono, Noto Serif; licencia OFL).
- **[L]** `text::fonts::add_font_data(Vec<u8>)` registra una fuente TTF/OTF desde memoria; hay `FontSource`, `DirectorySource`.
- **[L]** `project/src/graphic.rs` y `graphic_design.rs` importan `filmcraft_time::Tick`, `effect`, `keyframe`: están atados a efectos con fotogramas clave. **[C]** No se reutilizan; se toma la idea (capas con identificador, estilos por tramo) para etapas futuras.
- **[L]** `project` depende de `filmcraft-media` (tipos `Generator`, `MediaInfo`, `MediaKind`), que arrastra `image`, `dng` y `rayon`.

## 5. Qué se reutiliza sin arrastrar video/audio
Copiados (no enlazados; el repositorio original no se toca) a este espacio de trabajo:
- `crates/text` (+ `assets/fonts`) y `crates/color` tal cual. Cero cambios en su código.
- Tema oscuro, iconos Lucide y componentes de interfaz (`Theme.kt`, `Icons.kt`, `Components.kt`), solo con cambio de paquete.
- Configuración de Gradle/cargo-ndk/UniFFI y el flujo de GitHub Actions, adaptados.

Quedan fuera: `engine`, `render`, `project`, `media`, `codecs`, `export`, `audio-dsp` y los ~35 crates restantes.

## 6. Riesgos que siguen abiertos [P]
1. Nada de esto se compiló ni se probó (ver ESTADO.md).
2. Rendimiento del compositor en CPU con fotos grandes en un teléfono real (no medido).
3. Se transfiere el fotograma visible como `ByteArray` por JNA (≈10 MB por render a pantalla completa): puede ser lento; la mejora prevista es compartir memoria con la textura.
4. El editor de texto rasteriza con el motor propio; el rendimiento con fuentes grandes y textos largos no está medido.
5. Compilación de `harfrust`/`skrifa` para Android con la versión de Rust fijada (1.99.0 en rust-toolchain.toml): el original lo compila, pero sin probar aquí.
