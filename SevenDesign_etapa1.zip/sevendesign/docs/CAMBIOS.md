# Cambios respecto a Seven Cut Pro r27
- Seven Cut Pro **no se modificó**: se trabajó en una copia descomprimida y todo lo nuevo está en una carpeta aparte.
- Copiado sin cambios de código: `crates/color`, `crates/text`, `assets/fonts`, `assets/icons`.
- Copiado con cambio de nombre de paquete/propiedades: `Theme.kt`, `Icons.kt`, `Components.kt`, `app/build.gradle.kts`, `gradle/`, `proguard-rules.pro`, `gradle.properties`, `settings.gradle.kts`.
- Nuevo: `crates/design-doc`, `design-render`, `design-io`, `apps/sevendesign-android` (puente, bindgen, app), workflows, docs.
- Identificador de la app: `io.github.sevendesign`. Icono provisional vectorial (un "7" blanco sobre azul).
