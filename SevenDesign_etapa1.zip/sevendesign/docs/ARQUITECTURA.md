# Arquitectura de Seven Design (etapa 1)

```
sevendesign-android (app Kotlin + Compose)        apps/sevendesign-android/android
        │  Kotlin generado por UniFFI 0.32.2 (JNA)
sevendesign-android (cdylib Rust, DesignSession)   apps/sevendesign-android
        ├─ sevendesign-io      PNG/JPG, AssetStore (caché mip LRU), Project (carpeta .sevend), fuentes
        │     ├─ sevendesign-render   compositor por regiones/teselas, modos de fusión, texto → píxeles
        │     │     ├─ sevendesign-doc      documento, capas, deshacer/rehacer, JSON versionado
        │     │     └─ filmcraft-text       (copiado de Seven Cut Pro r27: fuentes, formas, rasterizado)
        │     └─ sevendesign-doc
        └─ filmcraft-color (copiado, requerido por filmcraft-text)
```

## design-doc (sin píxeles, sin E/S)
- `Document`: lienzo (px, dpi, fondo transparente o color), `layers` de abajo a arriba, `assets` (referencias a archivos), `next_id`.
- `Layer`: id, nombre, visible, bloqueada, opacidad, modo de fusión, `Transform` (centro, escala x/y, rotación) y `LayerKind` = `Image{asset,width,height}` | `Text(TextContent)`.
- `Editor`: documento + historial. Cada edición es un paso de deshacer (hasta 100). Los gestos continuos (arrastrar, deslizar, teclear) se **fusionan** en un solo paso por clave. Deshacer restaura una instantánea del documento: **barata porque el documento no contiene píxeles** (límite que sí tenía el deshacer de Seven Cut Pro, que copia el proyecto completo).
- JSON versionado (`FORMAT_VERSION = 1`): rechaza versiones futuras, completa campos que faltan con valores por defecto, repara ids y opacidades dañadas.
- Preparado para crecer: nuevos tipos de capa y campos se añaden sin romper archivos antiguos (`#[serde(default)]`).

## design-render
- `Renderer::render_region(doc, assets, región, escala)`: dibuja solo el rectángulo pedido (la parte visible en pantalla al zoom actual). Memoria ∝ región, no ∝ documento.
- `Renderer::render_full`: exportación en teselas de 512 px, sin costuras (probado en `tiled_export_has_no_seams`).
- Cada capa se muestrea con inversa de su transformación, bilinear premultiplicado, borde antialias por geometría. Modos: Normal, Multiplicar, Trama, Superponer, Oscurecer, Aclarar (fórmulas W3C, en sRGB como Photoshop).
- Texto: `filmcraft-text` (kerning, ligaduras, bidi, fuentes del usuario) se rasteriza al tamaño necesario (pasos de media octava, caché de 48 entradas) para que el texto no se vea borroso al ampliar.
- `AssetSource`: el compositor pide los píxeles a una fuente que puede devolver una copia menor (mip); el muestreo se hace por proporción.

## design-io
- `AssetStore`: decodifica el archivo a pedido; solo mantiene en memoria el nivel mip que pide la vista (1, ½, ¼… hasta 1/64) dentro de un presupuesto (256 MB), expulsando lo menos usado.
- `Project`: carpeta `.sevend` con `document.json`, `document.json.bak`, `assets/<id>.<ext>` (bytes originales), `fonts/`. Guardado **atómico** (escribe `.tmp`, sincroniza, rota a `.bak`, renombra). Al abrir, si `document.json` está dañado usa el `.bak`; si es de versión más nueva, lo rechaza sin sustituirlo.
- Importación: solo PNG/JPEG; se comprueba el tamaño antes de decodificar (máx. 80 Mpx) y se valida con una decodificación completa.
- Exportación: PNG (con transparencia o sin ella), JPG con calidad; escala configurable.

## sevendesign-android
- `DesignSession` (objeto UniFFI): una sesión = un proyecto. Renderizar y exportar trabajan sobre una copia del documento: editar nunca espera a un render.
- App: un único hilo de trabajo ordena todas las llamadas nativas; el lienzo se redibuja con retardo corto y a media resolución mientras hay un gesto activo.

## Qué NO está en la etapa 1 (no hay botones para ello)
Máscaras, pinceles, selecciones, vectores/Bézier, degradados, sombras, desenfoques, filtros, agrupar capas, recortar, redimensionar el lienzo, ajustes de color. Están en el plan de las etapas 2 y 3.
