# Seven Design

Editor de diseño gráfico para Android, independiente de Seven Cut Pro (que no se modifica). Rust (núcleo) + Kotlin/Jetpack Compose (interfaz), enlazados con UniFFI.

**Etapa 1** (ver docs/ESTADO.md: código escrito, **sin compilar ni probar todavía**): documentos con tamaño propio, lienzo con zoom y desplazamiento, importar PNG/JPG, panel de capas (visible, bloqueo, orden, duplicar, eliminar, opacidad, fusión), mover/rotar/escalar con los dedos, texto editable con fuentes TTF/OTF, deshacer/rehacer, guardar/abrir y exportar PNG/PNG transparente/JPG.

- docs/INVESTIGACION.md: lo que se comprobó en Seven Cut Pro r27.
- docs/ARQUITECTURA.md: diseño de los módulos.
- docs/ESTADO.md: qué está verificado y qué no, y cómo probarlo.
- docs/CAMBIOS.md: qué se copió y qué es nuevo.

Licencias: MIT OR Apache-2.0 (código; ver LICENSE-*). Fuentes Inter, JetBrains Mono y Noto Serif: SIL OFL (assets/fonts). Iconos Lucide: ISC (assets/icons/LICENSE-lucide.txt).
