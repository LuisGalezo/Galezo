package io.github.sevendesign

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import io.github.sevendesign.ui.EditorScreen
import io.github.sevendesign.ui.Fc
import io.github.sevendesign.ui.FcType
import io.github.sevendesign.ui.HomeScreen
import io.github.sevendesign.ui.SevenDesignTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val vm: DesignViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { SevenDesignTheme { Root(vm) } }
    }

    // Edits are kept on the phone as the app leaves the screen, so nothing is lost if it is closed.
    override fun onStop() {
        vm.saveIfDirty()
        super.onStop()
    }
}

@Composable
private fun Root(vm: DesignViewModel) {
    Box(Modifier.fillMaxSize().background(Fc.Black)) {
        if (vm.inEditor) EditorScreen(vm) else HomeScreen(vm)
        val msg = vm.message
        if (msg != null) {
            LaunchedEffect(msg) {
                delay(3500)
                if (vm.message == msg) vm.message = null
            }
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(24.dp)
                    .clip(RoundedCornerShape(12.dp)).background(Fc.Raised).padding(horizontal = 16.dp, vertical = 12.dp),
            ) { Text(msg, style = FcType.BodySmall, color = Fc.Title) }
        }
    }
}
