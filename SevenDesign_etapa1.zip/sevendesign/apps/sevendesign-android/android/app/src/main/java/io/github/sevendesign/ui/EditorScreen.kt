package io.github.sevendesign.ui

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsBottomHeight
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import io.github.sevendesign.DesignViewModel
import io.github.sevendesign.core.AlignInfo
import io.github.sevendesign.core.BlendInfo
import io.github.sevendesign.core.DocInfo
import io.github.sevendesign.core.ExportKind
import io.github.sevendesign.core.LayerInfo
import io.github.sevendesign.core.TextInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private enum class Tool { Move, View }
private enum class Panel { None, Layers, Props, Text, Export }

/** What the canvas last drew: the bitmap, the scale it was drawn at and where it starts. */
private class Shown(val image: ImageBitmap, val renderZoom: Float, val rx: Int, val ry: Int)

private fun corners(l: LayerInfo): List<Offset> {
    val r = Math.toRadians(l.rotationDeg)
    val c = cos(r)
    val s = sin(r)
    val hw = l.width.toDouble() / 2 * l.scaleX
    val hh = l.height.toDouble() / 2 * l.scaleY
    return listOf(-hw to -hh, hw to -hh, hw to hh, -hw to hh).map { (x, y) ->
        Offset((l.cx + x * c - y * s).toFloat(), (l.cy + x * s + y * c).toFloat())
    }
}

@Composable
fun EditorScreen(vm: DesignViewModel) {
    val info = vm.info ?: return
    var panel by remember { mutableStateOf(Panel.None) }
    var tool by remember { mutableStateOf(Tool.Move) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    var fitted by remember(vm.session) { mutableStateOf(false) }
    var gesturing by remember { mutableStateOf(false) }
    var live by remember { mutableStateOf<LayerInfo?>(null) }
    var shown by remember { mutableStateOf<Shown?>(null) }
    var pendingExport by remember { mutableStateOf<Triple<ExportKind, Int, Float>?>(null) }

    fun fit() {
        if (box.width == 0 || box.height == 0) return
        val z = min(box.width.toFloat() / info.width.toInt(), box.height.toFloat() / info.height.toInt()) * 0.92f
        zoom = z
        pan = Offset((box.width - info.width.toInt() * z) / 2f, (box.height - info.height.toInt() * z) / 2f)
    }
    LaunchedEffect(box, vm.session) {
        if (!fitted && box.width > 0) {
            fit()
            fitted = true
        }
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.importImage(uri) }
    val pickFont = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importFont(uri) }
    val exportMime = when (pendingExport?.first) {
        ExportKind.JPEG -> "image/jpeg"
        else -> "image/png"
    }
    val saveExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(exportMime)) { uri ->
        val p = pendingExport
        if (uri != null && p != null) vm.exportTo(uri, p.first, p.second, p.third)
    }

    BackHandler {
        if (panel != Panel.None) panel = Panel.None else vm.closeProject()
    }

    // ---- drawing the canvas: the visible part of the document, at the current zoom ----------
    LaunchedEffect(vm.revision, zoom, pan, box, gesturing, info.width, info.height) {
        val s = vm.session ?: return@LaunchedEffect
        if (box.width == 0) return@LaunchedEffect
        delay(if (gesturing) 16 else 50)
        val q = if (gesturing) 0.5f else 1f
        val rz = zoom * q
        val docW = info.width.toInt()
        val docH = info.height.toInt()
        val x0 = max(0f, (0f - pan.x) / zoom * rz)
        val y0 = max(0f, (0f - pan.y) / zoom * rz)
        val x1 = min(docW * rz, (box.width - pan.x) / zoom * rz)
        val y1 = min(docH * rz, (box.height - pan.y) / zoom * rz)
        val ix = x0.toInt()
        val iy = y0.toInt()
        val w = (x1.toInt() + 1 - ix).coerceAtMost((docW * rz).toInt() + 1 - ix)
        val h = (y1.toInt() + 1 - iy).coerceAtMost((docH * rz).toInt() + 1 - iy)
        if (w <= 0 || h <= 0) {
            shown = null
            return@LaunchedEffect
        }
        val bmp = withContext(Dispatchers.Default) {
            val r = s.renderView(ix, iy, w.toUInt(), h.toUInt(), rz)
            val rw = r.width.toInt()
            val rh = r.height.toInt()
            if (rw <= 0 || rh <= 0) {
                null
            } else {
                Bitmap.createBitmap(rw, rh, Bitmap.Config.ARGB_8888).also { it.copyPixelsFromBuffer(ByteBuffer.wrap(r.rgba)) }
            }
        }
        shown = bmp?.let { Shown(it.asImageBitmap(), rz, ix, iy) }
    }

    val currentTool by rememberUpdatedState(tool)
    val currentInfo by rememberUpdatedState(info)
    val currentZoom by rememberUpdatedState(zoom)
    val currentPan by rememberUpdatedState(pan)
    val slop = LocalViewConfiguration.current.touchSlop

    Column(Modifier.fillMaxSize().background(Fc.Black).statusBarsPadding()) {
        // ---- top bar ---------------------------------------------------------------------------
        Row(Modifier.fillMaxWidth().height(FcSize.TopBar).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            FcIconButton(LucideIcons.House.glyph(), "Inicio", { vm.closeProject() })
            Text(info.name, style = FcType.Body, color = Fc.Title, maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
            FcIconButton(LucideIcons.Maximize.glyph(), "Ajustar a la pantalla", { fit() })
            FcIconButton(LucideIcons.Undo2.glyph(), "Deshacer", { vm.undo() }, enabled = info.canUndo)
            FcIconButton(LucideIcons.Redo2.glyph(), "Rehacer", { vm.redo() }, enabled = info.canRedo)
            Box(
                Modifier.height(32.dp).clip(CircleShape).background(if (info.dirty) Fc.Accent else Fc.PillButton)
                    .clickable(enabled = info.dirty) { vm.save() }.padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) { Text(if (info.dirty) "Guardar" else "Guardado", style = FcType.Caption, color = Color.White) }
            FcIconButton(LucideIcons.Share2.glyph(), "Exportar", { panel = Panel.Export })
        }

        // ---- canvas + panels ---------------------------------------------------------------------
        Box(Modifier.weight(1f).fillMaxWidth().clipToBounds()) {
            Canvas(
                Modifier.fillMaxSize().onSizeChanged { box = it }.pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val inf = currentInfo
                        var target: LayerInfo? = if (currentTool == Tool.Move) inf.layers.firstOrNull { it.id == vm.selected && !it.locked } else null
                        var moved = 0f
                        var started = false
                        do {
                            val event = awaitPointerEvent()
                            val pz = event.calculateZoom()
                            val pr = event.calculateRotation()
                            val pp = event.calculatePan()
                            moved += pp.getDistance() + abs(pz - 1f) * 200f + abs(pr)
                            if (!started && moved > slop) {
                                started = true
                                gesturing = true
                            }
                            if (started) {
                                val t = target
                                if (t != null) {
                                    val z = currentZoom
                                    val moved2 = t.copy(
                                        cx = t.cx + pp.x / z, cy = t.cy + pp.y / z,
                                        scaleX = t.scaleX * pz, scaleY = t.scaleY * pz,
                                        rotationDeg = t.rotationDeg + pr,
                                    )
                                    target = moved2
                                    live = moved2
                                    vm.transform(moved2)
                                } else {
                                    val c = event.calculateCentroid(useCurrent = true)
                                    val oldZ = currentZoom
                                    val newZ = (oldZ * pz).coerceIn(0.02f, 32f)
                                    val k = newZ / oldZ
                                    pan = (currentPan - c) * k + c + pp
                                    zoom = newZ
                                }
                            }
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        } while (event.changes.any { it.pressed })
                        if (!started) {
                            val p = down.position
                            vm.selectAt(((p.x - currentPan.x) / currentZoom).toDouble(), ((p.y - currentPan.y) / currentZoom).toDouble())
                        } else {
                            gesturing = false
                            if (target != null) vm.endGesture()
                            live = null
                        }
                    }
                },
            ) {
                drawRect(Color(0xFF111111))
                val docW = info.width.toInt() * zoom
                val docH = info.height.toInt() * zoom
                val left = pan.x
                val top = pan.y
                // checkerboard behind transparent canvases
                val opaque = info.background?.let { (it shr 24) == 255u } ?: false
                clipRect(max(0f, left), max(0f, top), min(size.width, left + docW), min(size.height, top + docH)) {
                    if (!opaque) {
                        val sq = 16.dp.toPx()
                        drawRect(Color(0xFFE6E6E6), Offset(left, top), Size(docW, docH))
                        var yy = max(top, top + (-top / sq).toInt().coerceAtLeast(0) * sq)
                        var row = ((yy - top) / sq).toInt()
                        while (yy < min(size.height, top + docH)) {
                            var xx = max(left, left + (-left / sq).toInt().coerceAtLeast(0) * sq)
                            var col = ((xx - left) / sq).toInt()
                            while (xx < min(size.width, left + docW)) {
                                if ((row + col) % 2 == 1) drawRect(Color(0xFFB8B8B8), Offset(xx, yy), Size(sq, sq))
                                xx += sq
                                col++
                            }
                            yy += sq
                            row++
                        }
                    }
                    val sh = shown
                    if (sh != null) {
                        val k = zoom / sh.renderZoom
                        drawImage(
                            sh.image,
                            dstOffset = IntOffset((left + sh.rx * k).toInt(), (top + sh.ry * k).toInt()),
                            dstSize = IntSize((sh.image.width * k).toInt() + 1, (sh.image.height * k).toInt() + 1),
                            filterQuality = FilterQuality.Low,
                        )
                    }
                }
                drawRect(Color(0x55FFFFFF), Offset(left, top), Size(docW, docH), style = Stroke(1.dp.toPx()))
                // selection outline
                val sel = info.layers.firstOrNull { it.id == vm.selected }?.let { l -> if (live?.id == l.id) live else l }
                if (sel != null) {
                    val pts = corners(sel).map { Offset(left + it.x * zoom, top + it.y * zoom) }
                    val path = Path().apply {
                        moveTo(pts[0].x, pts[0].y)
                        for (i in 1..3) lineTo(pts[i].x, pts[i].y)
                        close()
                    }
                    drawPath(path, Fc.AccentLight, style = Stroke(2.dp.toPx()))
                    for (p in pts) drawCircle(Color.White, 5.dp.toPx(), p)
                    for (p in pts) drawCircle(Fc.Accent, 3.dp.toPx(), p)
                }
            }

            if (panel != Panel.None) {
                Box(Modifier.align(Alignment.BottomCenter)) {
                    SheetPanel(
                        title = when (panel) {
                            Panel.Layers -> "Capas"
                            Panel.Props -> "Propiedades"
                            Panel.Text -> "Texto"
                            else -> "Exportar"
                        },
                        onClose = { panel = Panel.None },
                    ) {
                        when (panel) {
                            Panel.Layers -> LayersPanel(vm, info)
                            Panel.Props -> PropsPanel(vm, info, onEditText = { panel = Panel.Text })
                            Panel.Text -> TextPanel(vm, info, onAddFont = { pickFont.launch(arrayOf("*/*")) })
                            else -> ExportPanel(info, vm.busy) { kind, quality, scale ->
                                pendingExport = Triple(kind, quality, scale)
                                saveExport.launch(info.name.ifBlank { "diseño" } + if (kind == ExportKind.JPEG) ".jpg" else ".png")
                            }
                            }
                    }
                }
            }
        }

        // ---- tool bar ------------------------------------------------------------------------------
        Row(Modifier.fillMaxWidth().background(Fc.PanelBand).horizontalScroll(rememberScrollState())) {
            ToolTile(DesignGlyphs.Move, "Mover", { tool = Tool.Move }, active = tool == Tool.Move)
            ToolTile(LucideIcons.Search.glyph(), "Vista", { tool = Tool.View }, active = tool == Tool.View)
            ToolTile(LucideIcons.Image.glyph(), "Imagen", { pickImage.launch("image/*") })
            ToolTile(LucideIcons.Type.glyph(), "Texto", {
                val sel = info.layers.firstOrNull { it.id == vm.selected }
                if (sel == null || !sel.isText) vm.addText("Texto")
                panel = Panel.Text
            }, active = panel == Panel.Text)
            ToolTile(LucideIcons.Layers.glyph(), "Capas", { panel = if (panel == Panel.Layers) Panel.None else Panel.Layers }, active = panel == Panel.Layers)
            ToolTile(LucideIcons.Blend.glyph(), "Ajustes", { panel = if (panel == Panel.Props) Panel.None else Panel.Props },
                enabled = vm.selected != null, active = panel == Panel.Props)
        }
        Spacer(Modifier.fillMaxWidth().windowInsetsBottomHeight(WindowInsets.navigationBars).background(Fc.PanelBand))
    }
}

/** A bottom sheet over the canvas: title, close, then the content (scrolls when tall). */
@Composable
private fun SheetPanel(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = FcSize.PanelInset).heightIn(max = 420.dp)
            .clip(RoundedCornerShape(topStart = FcSize.PanelCorner, topEnd = FcSize.PanelCorner)).background(Fc.Panel),
    ) {
        Row(Modifier.fillMaxWidth().padding(start = FcSize.PanelPadding, end = 8.dp).height(52.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = FcType.PanelTitle, color = Fc.Title, modifier = Modifier.weight(1f))
            FcIconButton(LucideIcons.ChevronDown.glyph(), "Cerrar panel", onClose)
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) { content() }
    }
}

@Composable
private fun LayersPanel(vm: DesignViewModel, info: DocInfo) {
    if (info.layers.isEmpty()) {
        Text("Sin capas. Añade una imagen o un texto.", style = FcType.BodySmall, color = Fc.Detail, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
        return
    }
    val sel = info.layers.firstOrNull { it.id == vm.selected }
    // top layer first, like the layer stack on screen
    for (l in info.layers.asReversed()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp).clip(RoundedCornerShape(12.dp))
                .background(if (l.id == vm.selected) Fc.Raised else Fc.Panel).clickable { vm.selected = l.id }.padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlyphIcon((if (l.isText) LucideIcons.Type else LucideIcons.Image).glyph(), Fc.Secondary, size = 20.dp)
            Text(l.name, style = FcType.Body, color = if (l.visible) Fc.Title else Fc.Detail, maxLines = 1, modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 14.dp))
            SelectChip(if (l.visible) "Visible" else "Oculta", l.visible, { vm.setVisible(l.id, !l.visible) })
            Spacer(Modifier.width(6.dp))
            SelectChip(if (l.locked) "Bloqueada" else "Libre", l.locked, { vm.setLocked(l.id, !l.locked) })
        }
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        val idx = info.layers.indexOfFirst { it.id == vm.selected }
        FcIconButton(LucideIcons.ChevronUp.glyph(), "Subir capa", { sel?.let { vm.moveLayer(it.id, idx + 1) } }, enabled = sel != null && idx < info.layers.size - 1)
        FcIconButton(LucideIcons.ChevronDown.glyph(), "Bajar capa", { sel?.let { vm.moveLayer(it.id, idx - 1) } }, enabled = sel != null && idx > 0)
        FcIconButton(LucideIcons.Copy.glyph(), "Duplicar capa", { sel?.let { vm.duplicateLayer(it.id) } }, enabled = sel != null)
        FcIconButton(LucideIcons.Trash2.glyph(), "Eliminar capa", { sel?.let { vm.deleteLayer(it.id) } }, enabled = sel != null && sel.locked.not(), tint = Fc.Negative)
    }
}

private val BlendNames = listOf(
    BlendInfo.NORMAL to "Normal", BlendInfo.MULTIPLY to "Multiplicar", BlendInfo.SCREEN to "Trama",
    BlendInfo.OVERLAY to "Superponer", BlendInfo.DARKEN to "Oscurecer", BlendInfo.LIGHTEN to "Aclarar",
)

@Composable
private fun PropsPanel(vm: DesignViewModel, info: DocInfo, onEditText: () -> Unit) {
    val l = info.layers.firstOrNull { it.id == vm.selected }
    if (l == null) {
        Text("Selecciona una capa tocándola en el lienzo o en Capas.", style = FcType.BodySmall, color = Fc.Detail, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
        return
    }
    if (l.locked) Text("La capa está bloqueada: desbloquéala en Capas para editarla.", style = FcType.BodySmall, color = Fc.Detail, modifier = Modifier.padding(horizontal = FcSize.PanelPadding, vertical = 4.dp))
    SliderRow("Opacidad", "${(l.opacity * 100).toInt()} %") {
        FcSlider(l.opacity, onChange = { vm.setOpacity(l.id, it) }, onDone = { vm.endGesture() }, enabled = !l.locked, look = SliderLook.Opacity, description = "Opacidad")
    }
    Spacer(Modifier.height(8.dp))
    Text("Modo de fusión", style = FcType.Label, color = Fc.Secondary, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
    Spacer(Modifier.height(6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for ((b, name) in BlendNames) SelectChip(name, l.blend == b, { if (!l.locked) vm.setBlend(l.id, b) })
    }
    if (l.isText) {
        Spacer(Modifier.height(12.dp))
        Box(Modifier.padding(horizontal = FcSize.PanelPadding)) { PrimaryButton("Editar texto", onEditText) }
    }
}

private val Palette = listOf(0xFF000000u, 0xFFFFFFFFu, 0xFFE53935u, 0xFFFFB300u, 0xFF43A047u, 0xFF1E88E5u, 0xFF8E24AAu)

@Composable
private fun TextPanel(vm: DesignViewModel, info: DocInfo, onAddFont: () -> Unit) {
    val l = info.layers.firstOrNull { it.id == vm.selected && it.isText }
    val t = l?.text
    if (l == null || t == null) {
        Text("Selecciona una capa de texto.", style = FcType.BodySmall, color = Fc.Detail, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
        return
    }
    fun update(n: TextInfo) = vm.setText(l.id, n)
    var field by remember(l.id) { mutableStateOf(t.text) }
    Column(Modifier.padding(horizontal = FcSize.PanelPadding)) {
        OutlinedTextField(field, { field = it; update(t.copy(text = it)) }, label = { Text("Texto") }, modifier = Modifier.fillMaxWidth(), enabled = !l.locked)
    }
    Spacer(Modifier.height(8.dp))
    val sizeFraction = sqrt(((t.sizePx - 8f) / 592f).coerceIn(0f, 1f))
    SliderRow("Tamaño", "${t.sizePx.toInt()} px") {
        FcSlider(sizeFraction, onChange = { f -> update(t.copy(sizePx = 8f + f * f * 592f)) }, onDone = { vm.endGesture() }, enabled = !l.locked, description = "Tamaño")
    }
    SliderRow("Espaciado", "${t.tracking.toInt()}") {
        FcSlider(((t.tracking + 100f) / 600f).coerceIn(0f, 1f), onChange = { f -> update(t.copy(tracking = f * 600f - 100f)) }, onDone = { vm.endGesture() }, enabled = !l.locked, description = "Espaciado")
    }
    Spacer(Modifier.height(8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SelectChip("Izquierda", t.align == AlignInfo.LEFT, { update(t.copy(align = AlignInfo.LEFT)) })
        SelectChip("Centro", t.align == AlignInfo.CENTER, { update(t.copy(align = AlignInfo.CENTER)) })
        SelectChip("Derecha", t.align == AlignInfo.RIGHT, { update(t.copy(align = AlignInfo.RIGHT)) })
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for (c in Palette) {
            Box(
                Modifier.height(36.dp).width(36.dp).clip(CircleShape).background(Color(c.toLong())).clickable { update(t.copy(color = c)) }
                    .then(if (t.color == c) Modifier.background(Color.Transparent) else Modifier),
            ) { if (t.color == c) Text("✓", color = if (c == 0xFFFFFFFFu) Color.Black else Color.White, modifier = Modifier.align(Alignment.Center)) }
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Fuente", style = FcType.Label, color = Fc.Secondary, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
    Spacer(Modifier.height(6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (f in vm.fonts) SelectChip(f.family, t.family == f.family, { update(t.copy(family = f.family, style = f.styles.firstOrNull { it == "Regular" } ?: f.styles.firstOrNull() ?: "Regular")) })
    }
    Spacer(Modifier.height(8.dp))
    val styles = vm.fonts.firstOrNull { it.family == t.family }?.styles.orEmpty()
    if (styles.size > 1) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (s in styles) SelectChip(s, t.style == s, { update(t.copy(style = s)) })
        }
        Spacer(Modifier.height(8.dp))
    }
    Box(Modifier.padding(horizontal = FcSize.PanelPadding)) { PrimaryButton("Añadir fuente TTF/OTF", onAddFont) }
}

@Composable
private fun ExportPanel(info: DocInfo, busy: Boolean, onExport: (ExportKind, Int, Float) -> Unit) {
    var kind by remember { mutableStateOf(ExportKind.PNG_TRANSPARENT) }
    var scale by remember { mutableFloatStateOf(1f) }
    var quality by remember { mutableFloatStateOf(0.9f) }
    val ow = (info.width.toInt() * scale).toInt().coerceAtLeast(1)
    val oh = (info.height.toInt() * scale).toInt().coerceAtLeast(1)
    val tooBig = ow.toLong() * oh > 100_000_000L
    Text("Formato", style = FcType.Label, color = Fc.Secondary, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
    Spacer(Modifier.height(6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SelectChip("PNG transparente", kind == ExportKind.PNG_TRANSPARENT, { kind = ExportKind.PNG_TRANSPARENT })
        SelectChip("PNG", kind == ExportKind.PNG, { kind = ExportKind.PNG })
        SelectChip("JPG", kind == ExportKind.JPEG, { kind = ExportKind.JPEG })
    }
    Spacer(Modifier.height(12.dp))
    Text("Resolución", style = FcType.Label, color = Fc.Secondary, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
    Spacer(Modifier.height(6.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = FcSize.PanelPadding), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (s in listOf(0.5f, 1f, 2f, 3f)) SelectChip("${if (s == s.toInt().toFloat()) s.toInt().toString() else s.toString()}×", scale == s, { scale = s })
    }
    if (kind == ExportKind.JPEG) {
        Spacer(Modifier.height(8.dp))
        SliderRow("Calidad JPG", "${(50 + quality * 50).toInt()}") { FcSlider(quality, onChange = { quality = it }, description = "Calidad") }
    }
    Spacer(Modifier.height(8.dp))
    Text("$ow × $oh px", style = FcType.BodySmall, color = if (tooBig) Fc.Negative else Fc.Detail, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
    if (kind != ExportKind.PNG_TRANSPARENT && info.background == null) {
        Text("El lienzo es transparente: este formato lo rellena de blanco.", style = FcType.Caption, color = Fc.Detail, modifier = Modifier.padding(horizontal = FcSize.PanelPadding))
    }
    Spacer(Modifier.height(12.dp))
    Box(Modifier.padding(horizontal = FcSize.PanelPadding)) {
        PrimaryButton(if (busy) "Exportando…" else "Exportar", { onExport(kind, (50 + quality * 50).toInt(), scale) }, enabled = !busy && !tooBig)
    }
}
