package io.github.sevendesign.ui

import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke

/** Seven Design's own glyphs, drawn on a 24-unit grid like the Lucide ones. */
object DesignGlyphs {
    /** Four arrows: move a layer. */
    val Move = Glyph.Drawn { c ->
        val u = size.minDimension / 24f
        val p = Path().apply {
            moveTo(12 * u, 2 * u); lineTo(12 * u, 22 * u)
            moveTo(2 * u, 12 * u); lineTo(22 * u, 12 * u)
            moveTo(9 * u, 5 * u); lineTo(12 * u, 2 * u); lineTo(15 * u, 5 * u)
            moveTo(9 * u, 19 * u); lineTo(12 * u, 22 * u); lineTo(15 * u, 19 * u)
            moveTo(5 * u, 9 * u); lineTo(2 * u, 12 * u); lineTo(5 * u, 15 * u)
            moveTo(19 * u, 9 * u); lineTo(22 * u, 12 * u); lineTo(19 * u, 15 * u)
        }
        drawPath(p, c, style = Stroke(width = ICON_STROKE * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
