package io.github.sevendesign

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import io.github.sevendesign.core.AlignInfo
import io.github.sevendesign.core.BlendInfo
import io.github.sevendesign.core.DesignSession
import io.github.sevendesign.core.DocInfo
import io.github.sevendesign.core.ExportKind
import io.github.sevendesign.core.FontFamilyInfo
import io.github.sevendesign.core.LayerInfo
import io.github.sevendesign.core.TextInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.Executors

data class ProjectEntry(val name: String, val path: String)

/**
 * The open project and the screens' state. Every call into the native library runs on ONE worker
 * thread, in order, so a drag's many small edits can never overtake each other; rendering uses its
 * own threads (see EditorScreen).
 */
class DesignViewModel(app: Application) : AndroidViewModel(app) {
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "design-worker") }.asCoroutineDispatcher()

    var session by mutableStateOf<DesignSession?>(null)
        private set
    var info by mutableStateOf<DocInfo?>(null)
        private set
    /** Bumped on every change that can alter the picture: the canvas draws again. */
    var revision by mutableIntStateOf(0)
        private set
    var selected by mutableStateOf<ULong?>(null)
    var inEditor by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
        private set
    var fonts by mutableStateOf<List<FontFamilyInfo>>(emptyList())
        private set
    var projects by mutableStateOf<List<ProjectEntry>>(emptyList())
        private set

    private val resolver get() = getApplication<Application>().contentResolver

    private fun projectsRoot() = File(getApplication<Application>().filesDir, "projects")

    fun loadProjects() {
        viewModelScope.launch(Dispatchers.IO) {
            projects = projectsRoot().listFiles().orEmpty()
                .filter { File(it, "document.json").isFile || File(it, "document.json.bak").isFile }
                .sortedByDescending { it.lastModified() }
                .map { ProjectEntry(it.name.substringAfter('_', it.name), it.absolutePath) }
        }
    }

    private fun attach(s: DesignSession) {
        session = s
        info = s.info()
        fonts = s.fonts()
        selected = null
        revision++
        inEditor = true
        val i = info
        if (i != null && i.recoveredFromBackup) message = "El documento estaba dañado: se abrió la copia de seguridad."
        if (i != null && i.missingAssets.isNotEmpty()) message = "Faltan imágenes: " + i.missingAssets.joinToString()
    }

    private fun fail(e: Exception, what: String) {
        message = e.message?.takeIf { it.isNotBlank() } ?: what
    }

    fun createProject(name: String, width: Int, height: Int, dpi: Float, background: UInt?) {
        viewModelScope.launch(worker) {
            try {
                val clean = name.trim().ifEmpty { "Sin título" }
                val safe = clean.replace(Regex("[^A-Za-z0-9._-]"), "-").take(40)
                val dir = File(projectsRoot(), "${System.currentTimeMillis()}_$safe")
                dir.parentFile?.mkdirs()
                attach(DesignSession.create(dir.absolutePath, clean, width.toUInt(), height.toUInt(), dpi, background))
            } catch (e: Exception) {
                fail(e, "No se pudo crear el documento")
            }
        }
    }

    fun openProject(path: String) {
        viewModelScope.launch(worker) {
            try {
                attach(DesignSession.open(path))
            } catch (e: Exception) {
                fail(e, "No se pudo abrir el documento")
            }
        }
    }

    fun closeProject() {
        val s = session
        inEditor = false
        viewModelScope.launch(worker) {
            try {
                if (s != null && info?.dirty == true) s.save()
            } catch (e: Exception) {
                fail(e, "No se pudo guardar")
            }
            session = null
            info = null
            loadProjects()
        }
    }

    fun saveIfDirty() {
        if (info?.dirty == true) save()
    }

    fun save() {
        edit { it.save() }
    }

    private fun refresh(s: DesignSession) {
        if (session !== s) return
        val i = s.info()
        info = i
        if (selected != null && i.layers.none { it.id == selected }) selected = null
        revision++
    }

    /** Runs [block] on the worker, then refreshes the state. */
    private fun edit(block: (DesignSession) -> Unit) {
        val s = session ?: return
        viewModelScope.launch(worker) {
            try {
                block(s)
                refresh(s)
            } catch (e: Exception) {
                fail(e, "No se pudo aplicar el cambio")
            }
        }
    }

    fun undo() = edit { it.undo() }
    fun redo() = edit { it.redo() }
    fun setOpacity(id: ULong, v: Float) = edit { it.setOpacity(id, v) }
    fun setBlend(id: ULong, b: BlendInfo) = edit { it.setBlend(id, b) }
    fun setVisible(id: ULong, v: Boolean) = edit { it.setVisible(id, v) }
    fun setLocked(id: ULong, v: Boolean) = edit { it.setLocked(id, v) }
    fun deleteLayer(id: ULong) = edit { it.deleteLayer(id) }
    fun moveLayer(id: ULong, index: Int) = edit { it.moveLayer(id, index.toUInt()) }
    fun setText(id: ULong, t: TextInfo) = edit { it.setText(id, t) }
    fun endGesture() = edit { it.endGesture() }

    fun duplicateLayer(id: ULong) = edit { selected = it.duplicateLayer(id) }

    fun addText(text: String) = edit { selected = it.addText(text) }

    /** One step of a drag or pinch: the new absolute transform. Only the picture is redrawn. */
    fun transform(l: LayerInfo) {
        val s = session ?: return
        viewModelScope.launch(worker) {
            try {
                s.setTransform(l.id, l.cx, l.cy, l.scaleX, l.scaleY, l.rotationDeg)
                revision++
            } catch (e: Exception) {
                fail(e, "No se pudo mover la capa")
            }
        }
    }

    fun selectAt(x: Double, y: Double) {
        val s = session ?: return
        viewModelScope.launch(worker) { selected = s.hitTest(x, y) }
    }

    fun importImage(uri: Uri) {
        val s = session ?: return
        viewModelScope.launch(worker) {
            busy = true
            try {
                val raw = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("No se pudo leer la imagen")
                val name = displayName(uri)?.substringBeforeLast('.') ?: "Imagen"
                selected = s.importImage(name, upright(raw))
                refresh(s)
            } catch (e: Exception) {
                fail(e, "No se pudo importar la imagen")
            } finally {
                busy = false
            }
        }
    }

    fun importFont(uri: Uri) {
        val s = session ?: return
        viewModelScope.launch(worker) {
            try {
                val data = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("No se pudo leer la fuente")
                val names = s.importFont(displayName(uri) ?: "font.ttf", data)
                fonts = s.fonts()
                message = "Fuente añadida: " + names.firstOrNull().orEmpty()
            } catch (e: Exception) {
                fail(e, "Ese archivo no es una fuente TTF/OTF válida")
            }
        }
    }

    fun exportTo(uri: Uri, kind: ExportKind, quality: Int, scale: Float) {
        val s = session ?: return
        viewModelScope.launch(worker) {
            busy = true
            try {
                val bytes = s.export(kind, quality.coerceIn(1, 100).toUByte(), scale)
                val out = resolver.openOutputStream(uri) ?: error("No se pudo escribir el archivo")
                out.use { it.write(bytes) }
                message = "Exportado (${bytes.size / 1024} KB)"
            } catch (e: Exception) {
                fail(e, "No se pudo exportar")
            } finally {
                busy = false
            }
        }
    }

    private fun displayName(uri: Uri): String? =
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }

    /** Applies a camera photo's EXIF rotation (the native side reads pixels as stored). */
    private fun upright(bytes: ByteArray): ByteArray {
        val orientation = try {
            ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            else -> return bytes
        }
        val src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return bytes
        val turned = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        val out = ByteArrayOutputStream()
        turned.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }
}

val DefaultAlign = AlignInfo.LEFT
