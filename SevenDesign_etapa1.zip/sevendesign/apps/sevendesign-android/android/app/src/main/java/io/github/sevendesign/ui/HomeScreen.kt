package io.github.sevendesign.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.github.sevendesign.DesignViewModel

private data class Preset(val label: String, val w: Int, val h: Int, val dpi: Float = 72f)

private val Presets = listOf(
    Preset("Cuadrado 1080×1080", 1080, 1080),
    Preset("Historia 1080×1920", 1080, 1920),
    Preset("Full HD 1920×1080", 1920, 1080),
    Preset("A4 2480×3508", 2480, 3508, 300f),
    Preset("Póster 3000×4000", 3000, 4000),
)

@Composable
fun HomeScreen(vm: DesignViewModel) {
    var creating by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadProjects() }
    Column(Modifier.fillMaxSize().background(Fc.Black).systemBarsPadding().padding(horizontal = 24.dp)) {
        Spacer(Modifier.height(32.dp))
        Text("Seven Design", style = FcType.Header.copy(fontSize = 28.sp), color = Fc.Title)
        Spacer(Modifier.height(24.dp))
        PrimaryButton("Nuevo documento", onClick = { creating = true })
        Spacer(Modifier.height(24.dp))
        Text("Proyectos", style = FcType.PanelTitle, color = Fc.Title)
        Spacer(Modifier.height(8.dp))
        if (vm.projects.isEmpty()) {
            Text("Aún no hay proyectos. Crea tu primer documento.", style = FcType.BodySmall, color = Fc.Detail)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(vm.projects, key = { it.path }) { p ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Fc.Raised)
                            .clickable { vm.openProject(p.path) }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) { Text(p.name, style = FcType.Body, color = Fc.Title) }
                }
            }
        }
    }
    if (creating) NewDocumentDialog(onDismiss = { creating = false }) { name, w, h, dpi, bg ->
        creating = false
        vm.createProject(name, w, h, dpi, bg)
    }
}

@Composable
private fun NewDocumentDialog(onDismiss: () -> Unit, onCreate: (String, Int, Int, Float, UInt?) -> Unit) {
    var name by remember { mutableStateOf("Sin título") }
    var width by remember { mutableStateOf("1080") }
    var height by remember { mutableStateOf("1080") }
    var dpi by remember { mutableStateOf(72f) }
    var bg by remember { mutableStateOf(0) } // 0 white, 1 black, 2 transparent
    val w = width.toIntOrNull()
    val h = height.toIntOrNull()
    val valid = w != null && h != null && w in 1..16384 && h in 1..16384 && w.toLong() * h <= 50_000_000L
    FcDialog(
        title = "Nuevo documento",
        confirm = "Crear",
        onConfirm = {
            val color: UInt? = when (bg) {
                0 -> 0xFFFFFFFFu
                1 -> 0xFF000000u
                else -> null
            }
            onCreate(name, w ?: 1080, h ?: 1080, dpi, color)
        },
        onDismiss = onDismiss,
        confirmEnabled = valid,
    ) {
        OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (p in Presets) SelectChip(p.label, selected = width == p.w.toString() && height == p.h.toString(), onClick = {
                width = p.w.toString(); height = p.h.toString(); dpi = p.dpi
            })
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(width, { width = it.filter(Char::isDigit).take(5) }, label = { Text("Ancho px") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
            OutlinedTextField(height, { height = it.filter(Char::isDigit).take(5) }, label = { Text("Alto px") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f))
        }
        if (!valid) {
            Spacer(Modifier.height(8.dp))
            Text("Cada lado de 1 a 16 384 px y como máximo 50 millones de píxeles.", style = FcType.Caption, color = Fc.Negative)
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SelectChip("Blanco", bg == 0, { bg = 0 })
            SelectChip("Negro", bg == 1, { bg = 1 })
            SelectChip("Transparente", bg == 2, { bg = 2 })
        }
    }
}
