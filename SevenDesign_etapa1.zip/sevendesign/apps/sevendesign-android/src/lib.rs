//! Seven Design for Android: the native side of the app, with Kotlin bindings from UniFFI.
//!
//! One [`DesignSession`] is one open project. Every method may be called from any thread; the
//! project lock is held only while a call reads or edits the document. Rendering and export
//! work on a copy of the (small, pixel-free) document, so the screen keeps drawing while the
//! user edits, and editing never waits for a render.
//!
//! Colours cross the bridge as `0xAARRGGBB` (`u32`, Android's `Color.toArgb()` layout).
#![forbid(unsafe_code)]

use std::sync::{Arc, Mutex, MutexGuard, PoisonError};

use sevendesign_doc::{
    Background, BlendMode, DocError, Document, Layer, LayerId, LayerKind, Rgba, TextAlign, TextContent, Transform,
};
use sevendesign_io::{ExportFormat, IoError, Project, flatten_color};
use sevendesign_render::{IRect, Raster};

uniffi::setup_scaffolding!();

/// What went wrong, as a message the user can read.
#[derive(Debug, thiserror::Error, uniffi::Error)]
#[uniffi(flat_error)]
pub enum DesignError {
    #[error("{0}")]
    Failed(String),
}

impl From<IoError> for DesignError {
    fn from(e: IoError) -> Self {
        DesignError::Failed(e.to_string())
    }
}

impl From<DocError> for DesignError {
    fn from(e: DocError) -> Self {
        DesignError::Failed(e.to_string())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, uniffi::Enum)]
pub enum BlendInfo {
    Normal,
    Multiply,
    Screen,
    Overlay,
    Darken,
    Lighten,
}

impl From<BlendMode> for BlendInfo {
    fn from(b: BlendMode) -> Self {
        match b {
            BlendMode::Normal => BlendInfo::Normal,
            BlendMode::Multiply => BlendInfo::Multiply,
            BlendMode::Screen => BlendInfo::Screen,
            BlendMode::Overlay => BlendInfo::Overlay,
            BlendMode::Darken => BlendInfo::Darken,
            BlendMode::Lighten => BlendInfo::Lighten,
        }
    }
}

impl From<BlendInfo> for BlendMode {
    fn from(b: BlendInfo) -> Self {
        match b {
            BlendInfo::Normal => BlendMode::Normal,
            BlendInfo::Multiply => BlendMode::Multiply,
            BlendInfo::Screen => BlendMode::Screen,
            BlendInfo::Overlay => BlendMode::Overlay,
            BlendInfo::Darken => BlendMode::Darken,
            BlendInfo::Lighten => BlendMode::Lighten,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, uniffi::Enum)]
pub enum AlignInfo {
    Left,
    Center,
    Right,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, uniffi::Enum)]
pub enum ExportKind {
    /// PNG keeping transparency.
    PngTransparent,
    /// PNG flattened over the canvas colour (white for a transparent canvas).
    Png,
    Jpeg,
}

/// A text layer's content and look.
#[derive(Debug, Clone, uniffi::Record)]
pub struct TextInfo {
    pub text: String,
    pub family: String,
    pub style: String,
    pub size_px: f32,
    /// 0xAARRGGBB
    pub color: u32,
    pub align: AlignInfo,
    pub tracking: f32,
    pub leading: f32,
    /// Wrap width in canvas pixels; none = one unwrapped line per paragraph.
    pub box_width: Option<f32>,
}

#[derive(Debug, Clone, uniffi::Record)]
pub struct LayerInfo {
    pub id: u64,
    pub name: String,
    pub is_text: bool,
    pub visible: bool,
    pub locked: bool,
    pub opacity: f32,
    pub blend: BlendInfo,
    /// Centre of the layer on the canvas, in canvas pixels.
    pub cx: f64,
    pub cy: f64,
    pub scale_x: f64,
    pub scale_y: f64,
    pub rotation_deg: f64,
    /// Natural size in canvas pixels (before scaling).
    pub width: u32,
    pub height: u32,
    pub text: Option<TextInfo>,
}

#[derive(Debug, Clone, uniffi::Record)]
pub struct DocInfo {
    pub name: String,
    pub width: u32,
    pub height: u32,
    pub dpi: f32,
    /// 0xAARRGGBB, or none for a transparent canvas.
    pub background: Option<u32>,
    pub can_undo: bool,
    pub can_redo: bool,
    pub undo_label: Option<String>,
    /// Edits since the last save.
    pub dirty: bool,
    /// Bottom to top.
    pub layers: Vec<LayerInfo>,
    /// Pictures the document uses whose file is missing.
    pub missing_assets: Vec<String>,
    /// The project was opened from its backup because the main file was damaged.
    pub recovered_from_backup: bool,
}

#[derive(Debug, Clone, uniffi::Record)]
pub struct FontFamilyInfo {
    pub family: String,
    pub styles: Vec<String>,
}

/// Premultiplied RGBA8, ready for an Android `Bitmap` (ARGB_8888).
#[derive(Debug, Clone, uniffi::Record)]
pub struct RenderedImage {
    pub width: u32,
    pub height: u32,
    pub rgba: Vec<u8>,
}

fn to_argb(c: Rgba) -> u32 {
    (u32::from(c.0[3]) << 24) | (u32::from(c.0[0]) << 16) | (u32::from(c.0[1]) << 8) | u32::from(c.0[2])
}

fn from_argb(c: u32) -> Rgba {
    Rgba([(c >> 16) as u8, (c >> 8) as u8, c as u8, (c >> 24) as u8])
}

fn text_info(t: &TextContent) -> TextInfo {
    TextInfo {
        text: t.text.clone(),
        family: t.family.clone(),
        style: t.style.clone(),
        size_px: t.size_px,
        color: to_argb(t.color),
        align: match t.align {
            TextAlign::Left => AlignInfo::Left,
            TextAlign::Center => AlignInfo::Center,
            TextAlign::Right => AlignInfo::Right,
        },
        tracking: t.tracking,
        leading: t.leading,
        box_width: t.box_width,
    }
}

fn text_content(t: &TextInfo) -> TextContent {
    TextContent {
        text: t.text.clone(),
        family: t.family.clone(),
        style: t.style.clone(),
        size_px: if t.size_px.is_finite() { t.size_px.clamp(1.0, 4096.0) } else { 96.0 },
        color: from_argb(t.color),
        align: match t.align {
            AlignInfo::Left => TextAlign::Left,
            AlignInfo::Center => TextAlign::Center,
            AlignInfo::Right => TextAlign::Right,
        },
        tracking: t.tracking,
        leading: t.leading,
        box_width: t.box_width.filter(|w| w.is_finite() && *w > 0.0),
    }
}

fn premultiply(px: &mut [u8]) {
    for p in px.chunks_exact_mut(4) {
        let a = u32::from(p[3]);
        if a < 255 {
            for c in &mut p[0..3] {
                *c = ((u32::from(*c) * a + 127) / 255) as u8;
            }
        }
    }
}

/// One open project.
#[derive(uniffi::Object)]
pub struct DesignSession {
    project: Mutex<Project>,
}

impl DesignSession {
    fn lock(&self) -> MutexGuard<'_, Project> {
        self.project.lock().unwrap_or_else(PoisonError::into_inner)
    }

    fn layer_info(p: &Project, l: &Layer) -> LayerInfo {
        let (width, height) = p.renderer.layer_size(l).unwrap_or((0, 0));
        LayerInfo {
            id: l.id,
            name: l.name.clone(),
            is_text: matches!(l.kind, LayerKind::Text(_)),
            visible: l.visible,
            locked: l.locked,
            opacity: l.opacity,
            blend: l.blend.into(),
            cx: l.transform.cx,
            cy: l.transform.cy,
            scale_x: l.transform.scale_x,
            scale_y: l.transform.scale_y,
            rotation_deg: l.transform.rotation_deg,
            width,
            height,
            text: match &l.kind {
                LayerKind::Text(t) => Some(text_info(t)),
                LayerKind::Image { .. } => None,
            },
        }
    }
}

#[uniffi::export]
impl DesignSession {
    /// Creates a project folder at `dir` with an empty canvas. `background` is 0xAARRGGBB, or
    /// none for a transparent canvas.
    #[uniffi::constructor]
    pub fn create(dir: String, name: String, width: u32, height: u32, dpi: f32, background: Option<u32>) -> Result<Arc<Self>, DesignError> {
        let bg = background.map_or(Background::Transparent, |c| Background::Solid(from_argb(c)));
        let doc = Document::new(&name, width, height, dpi, bg)?;
        let project = Project::create(std::path::Path::new(&dir), doc)?;
        Ok(Arc::new(Self { project: Mutex::new(project) }))
    }

    /// Opens the project folder at `dir`.
    #[uniffi::constructor]
    pub fn open(dir: String) -> Result<Arc<Self>, DesignError> {
        let project = Project::open(std::path::Path::new(&dir))?;
        Ok(Arc::new(Self { project: Mutex::new(project) }))
    }

    pub fn info(&self) -> DocInfo {
        let p = self.lock();
        let ed = &p.editor;
        let d = ed.doc();
        DocInfo {
            name: d.name.clone(),
            width: d.width,
            height: d.height,
            dpi: d.dpi,
            background: match d.background {
                Background::Transparent => None,
                Background::Solid(c) => Some(to_argb(c)),
            },
            can_undo: ed.can_undo(),
            can_redo: ed.can_redo(),
            undo_label: ed.undo_label().map(str::to_string),
            dirty: ed.is_dirty(),
            layers: d.layers.iter().map(|l| Self::layer_info(&p, l)).collect(),
            missing_assets: p.missing_assets(),
            recovered_from_backup: p.recovered_from_backup,
        }
    }

    pub fn save(&self) -> Result<(), DesignError> {
        Ok(self.lock().save()?)
    }

    pub fn undo(&self) -> bool {
        self.lock().editor.undo()
    }

    pub fn redo(&self) -> bool {
        self.lock().editor.redo()
    }

    /// Closes the open drag/typing gesture: the next change starts a new undo step.
    pub fn end_gesture(&self) {
        self.lock().editor.end_gesture();
    }

    /// Imports a PNG or JPEG (the bytes of the file) as a new top layer.
    pub fn import_image(&self, name: String, bytes: Vec<u8>) -> Result<u64, DesignError> {
        Ok(self.lock().import_image(&name, &bytes)?)
    }

    /// Adds a text layer with default look, sized to the canvas. Returns its id.
    pub fn add_text(&self, text: String) -> u64 {
        let mut p = self.lock();
        let size = (p.editor.doc().width as f32 / 10.0).clamp(12.0, 400.0);
        p.editor.add_text_layer(TextContent { text, size_px: size, ..Default::default() })
    }

    pub fn set_text(&self, id: u64, text: TextInfo) -> Result<(), DesignError> {
        Ok(self.lock().editor.set_text(id, text_content(&text))?)
    }

    pub fn set_transform(&self, id: u64, cx: f64, cy: f64, scale_x: f64, scale_y: f64, rotation_deg: f64) -> Result<(), DesignError> {
        let ok = [cx, cy, scale_x, scale_y, rotation_deg].iter().all(|v| v.is_finite());
        if !ok {
            return Err(DesignError::Failed("transform is not a number".into()));
        }
        let t = Transform { cx, cy, scale_x, scale_y, rotation_deg };
        Ok(self.lock().editor.set_transform(id, t)?)
    }

    pub fn set_opacity(&self, id: u64, opacity: f32) -> Result<(), DesignError> {
        Ok(self.lock().editor.set_opacity(id, opacity)?)
    }

    pub fn set_blend(&self, id: u64, blend: BlendInfo) -> Result<(), DesignError> {
        Ok(self.lock().editor.set_blend(id, blend.into())?)
    }

    pub fn set_visible(&self, id: u64, visible: bool) -> Result<(), DesignError> {
        Ok(self.lock().editor.set_visible(id, visible)?)
    }

    pub fn set_locked(&self, id: u64, locked: bool) -> Result<(), DesignError> {
        Ok(self.lock().editor.set_locked(id, locked)?)
    }

    pub fn rename_layer(&self, id: u64, name: String) -> Result<(), DesignError> {
        Ok(self.lock().editor.rename(id, &name)?)
    }

    pub fn delete_layer(&self, id: u64) -> Result<(), DesignError> {
        Ok(self.lock().editor.delete_layer(id)?)
    }

    pub fn duplicate_layer(&self, id: u64) -> Result<u64, DesignError> {
        Ok(self.lock().editor.duplicate_layer(id)?)
    }

    /// Moves a layer to `index` in the bottom-to-top list (0 = bottom).
    pub fn move_layer(&self, id: u64, index: u32) -> Result<(), DesignError> {
        Ok(self.lock().editor.move_layer(id, index as usize)?)
    }

    /// Adds a TTF/OTF font to the project; returns its "family / style" names.
    pub fn import_font(&self, file_name: String, data: Vec<u8>) -> Result<Vec<String>, DesignError> {
        Ok(self.lock().import_font(&file_name, data)?)
    }

    /// Every font family text layers can use (bundled, system-scanned and the user's).
    pub fn fonts(&self) -> Vec<FontFamilyInfo> {
        filmcraft_text::families().into_iter().map(|(family, styles)| FontFamilyInfo { family, styles }).collect()
    }

    /// Topmost visible layer under the canvas point, if any.
    pub fn hit_test(&self, x: f64, y: f64) -> Option<u64> {
        let p = self.lock();
        p.renderer.hit_test(p.editor.doc(), x, y)
    }

    /// The layer's four corners on the canvas as x0,y0,x1,y1,x2,y2,x3,y3 (empty if unknown).
    pub fn layer_corners(&self, id: u64) -> Vec<f64> {
        let p = self.lock();
        let Some(layer) = p.editor.doc().layer(id) else { return Vec::new() };
        p.renderer.layer_corners(layer).map(|c| c.iter().flat_map(|(x, y)| [*x, *y]).collect()).unwrap_or_default()
    }

    /// Draws `w` x `h` output pixels starting at output pixel (`x`, `y`), the canvas shown at
    /// `scale` output pixels per canvas pixel. Premultiplied RGBA8.
    pub fn render_view(&self, x: i32, y: i32, w: u32, h: u32, scale: f32) -> RenderedImage {
        let (doc, store, renderer) = {
            let p = self.lock();
            (p.editor.doc().clone(), p.store.clone(), p.renderer.clone())
        };
        let mut r: Raster = renderer.render_region(&doc, &*store, IRect { x, y, w, h }, scale);
        premultiply(&mut r.px);
        RenderedImage { width: r.w, height: r.h, rgba: r.px }
    }

    /// Renders the whole canvas at `scale` and encodes it. `quality` (1..=100) is for JPEG.
    pub fn export(&self, kind: ExportKind, quality: u8, scale: f32) -> Result<Vec<u8>, DesignError> {
        let (doc, store, renderer) = {
            let p = self.lock();
            (p.editor.doc().clone(), p.store.clone(), p.renderer.clone())
        };
        let over = flatten_color(&doc);
        let format = match kind {
            ExportKind::PngTransparent => ExportFormat::PngTransparent,
            ExportKind::Png => ExportFormat::Png { flatten_over: over },
            ExportKind::Jpeg => ExportFormat::Jpeg { quality, flatten_over: over },
        };
        let raster = renderer.render_full(&doc, &*store, scale).map_err(IoError::from)?;
        Ok(sevendesign_io::encode(&raster, format)?)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn session(dir: &std::path::Path) -> Arc<DesignSession> {
        DesignSession::create(dir.join("p").to_string_lossy().into_owned(), "p".into(), 200, 100, 72.0, Some(0xFF102030)).unwrap()
    }

    #[test]
    fn colours_round_trip() {
        assert_eq!(to_argb(from_argb(0x80FF8040)), 0x80FF8040);
        assert_eq!(from_argb(0xFF102030), Rgba([0x10, 0x20, 0x30, 0xFF]));
    }

    #[test]
    fn text_layer_edit_undo_and_render() {
        let tmp = tempfile::tempdir().unwrap();
        let s = session(tmp.path());
        let id = s.add_text("Hola".into());
        let info = s.info();
        assert_eq!(info.layers.len(), 1);
        assert!(info.layers[0].is_text && info.layers[0].width > 0);
        let img = s.render_view(0, 0, 200, 100, 1.0);
        assert_eq!((img.width, img.height), (200, 100));
        // the text adds pixels that differ from the plain background
        let bg = &img.rgba[0..4];
        assert!(img.rgba.chunks_exact(4).any(|p| p != bg));
        s.set_opacity(id, 0.5).unwrap();
        assert!(s.undo());
        assert!(s.undo());
        assert!(s.info().layers.is_empty());
        assert!(s.redo());
    }

    #[test]
    fn export_png_and_jpg() {
        let tmp = tempfile::tempdir().unwrap();
        let s = session(tmp.path());
        s.add_text("Hola".into());
        let png = s.export(ExportKind::PngTransparent, 90, 1.0).unwrap();
        assert_eq!(&png[1..4], b"PNG");
        let jpg = s.export(ExportKind::Jpeg, 90, 1.0).unwrap();
        assert_eq!(&jpg[0..2], &[0xFF, 0xD8]);
    }

    #[test]
    fn save_and_open() {
        let tmp = tempfile::tempdir().unwrap();
        let s = session(tmp.path());
        s.add_text("Hola".into());
        s.save().unwrap();
        let t = DesignSession::open(tmp.path().join("p").to_string_lossy().into_owned()).unwrap();
        assert_eq!(t.info().layers.len(), 1);
        assert!(!t.info().dirty);
    }

    #[test]
    fn premultiply_scales_colour_by_alpha() {
        let mut px = [200, 100, 50, 128, 10, 20, 30, 255];
        premultiply(&mut px);
        assert_eq!(&px[0..4], &[100, 50, 25, 128]);
        assert_eq!(&px[4..8], &[10, 20, 30, 255]);
    }

    #[test]
    fn bad_input_is_an_error_not_a_panic() {
        let tmp = tempfile::tempdir().unwrap();
        let s = session(tmp.path());
        assert!(s.import_image("x".into(), b"nope".to_vec()).is_err());
        assert!(s.set_transform(99, f64::NAN, 0.0, 1.0, 1.0, 0.0).is_err());
        assert!(DesignSession::create("/nonexistent-root-xyz/p".into(), "p".into(), 0, 10, 72.0, None).is_err());
    }
}
