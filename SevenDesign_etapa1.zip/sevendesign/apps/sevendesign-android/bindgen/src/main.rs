//! `uniffi-bindgen` for `sevendesign-android` (`android/app/build.gradle.kts` runs it).
#![forbid(unsafe_code)]

fn main() {
    uniffi::uniffi_bindgen_main()
}
