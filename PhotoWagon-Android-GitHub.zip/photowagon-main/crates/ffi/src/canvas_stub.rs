//! The canvas where there is no GPU surface to draw on (Android for now): the same API as
//! `canvas.rs`, but [`Canvas::new`] always fails, so `Editor::attach` returns an error and the
//! app shows the document with `Editor::preview_image` or `Editor::render_region`, which the CPU
//! compositor renders. Everything else in the engine works as on iOS.

use photocraft_doc::Document;
use photocraft_engine::Session;
use photocraft_geom::Rect;
use photocraft_gpu::viewport::View;

pub struct Canvas {
    /// Pasteboard colour around the document (kept so `Editor` compiles the same on every platform).
    pub background: wgpu::Color,
}

impl Canvas {
    pub fn new(_layer: u64, _width: u32, _height: u32) -> Result<Self, String> {
        Err("the GPU canvas isn't available on this platform yet; draw preview_image or render_region instead".into())
    }

    pub fn retarget(&mut self, _layer: u64, _width: u32, _height: u32) -> Result<(), String> {
        Err("the GPU canvas isn't available on this platform yet".into())
    }

    pub fn release(&mut self, _layer: u64) {}

    pub fn resize(&mut self, _width: u32, _height: u32) {}

    pub fn healthy(&self) -> bool {
        false
    }

    pub fn ready(&self) -> bool {
        false
    }

    pub fn holds(&self, _doc: &Document) -> bool {
        false
    }

    pub fn refresh(&mut self, _session: &Session, _doc: &Document, _damage: Option<Rect>) {}

    pub fn draw(&mut self, _view: &View) {}
}
